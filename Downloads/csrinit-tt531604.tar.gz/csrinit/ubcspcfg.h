/* If we wish to use CRC's, then change 0 to 1 in the next line */
#define UBCSP_CRC 1

/* Define some basic types - change these for your architecture */
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;
typedef signed char int8;
typedef signed short int16;
typedef signed int int32;

/* The defines below require a printf function to be available */

/* Do we want to show packet errors in debug output */
#define SHOW_PACKET_ERRORS	0
/* Do we want to show Link Establishment State transitions in debug output */
#define SHOW_LE_STATES		0

/* if running on a PC, rather than a go, then we need to specify 115,200baud not 230,400 */
#define USE_PC_BAUDRATE		0
