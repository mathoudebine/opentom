// 
// This header file contains the patches for CSR BC4-ROM build id 1958.
// Author: Jeroen Egelmeers
// 
// 
// Following information about the patches from CSR:
// =============================================================================
// 
// Created by patchmaker.pl $Revision: #17 $ $Date: 2007/03/07 $
// Creation date: Fri May 25 14:19:09 2007
// 
// Patch is for build 1958 odj_4hci_rom_bt2.0_19p2_0503071059_encr128
// Input file: build_1958_patches.xap.
// Depot file: //depot/bc/19p2/dev/patches/1958/build_1958_patches.xap
// File revision: 13
// 
// This patch is B-10910. It fixes B-8062, B-6989, B-8710, B-6002, B-6334,
// B-21798 and optionally B-5329 and B-4509.
// 
// B-8062
// A race condition has been identified within the BlueCore firmware which
// can cause packet transmission failure under some circumstances. This 
// causes reduced link performance.
// 
// B-6989
// Enhancements to the EDR temperature compensation algorithm to reduce the drop
// in EDR output power at high temperatures. Must be used with
// PSKEY_TEMPERATURE_VS_DELTA_TX_BB_MR_PAYLOAD &
// PSKEY_TEMPERATURE_VS_DELTA_TX_BB_MR_HEADER containing entries at 54 and 55�C.
// The recommended settings for these PSKEYS are 
//  For PSKEY_TEMPERATURE_VS_DELTA_TX_BB_MR_PAYLOAD:
//   { -30, 8 }, { 0, 4 }, { 25, 0 }, { 54, 0 }, { 55, 10 }, { 85, 4 },
//     { 105, 4 }
//  or as raw words:
//   0xffe2, 0x0008, 0x0000, 0x0004, 0x0019, 0x0000, 0x0036, 0x0000, 0x0037,
//   0x000a, 0x0055, 0x0004, 0x0069, 0x0004 
// 
//  For PSKEY_TEMPERATURE_VS_DELTA_TX_BB_MR_HEADER:
//    { -30, 5 }, { 0, 4 }, { 25, 0 }, { 54, -4 }, { 55, 5 }, { 85, 4 },
//     { 105, 4 }
//  or as raw words:
//   0xffe2, 0x0005, 0x0000, 0x0004, 0x0019, 0x0000, 0x0036, 0xfffc, 0x0037,
//   0x0005, 0x0055, 0x0004, 0x0069, 0x0004
// 
// B-8710
// Data stalls have been observed for EDR devices placed within a few
// centimetres of each other, where BlueCore cannot receive the EDR packet and
// so continuously NAKs or does not respond. This is caused by a fault in the
// chip's automatic gain control (AGC) software. The stall eventually clears,
// but has been observed to cause up to 5 seconds of delay on an EDR connection
// when data is transfered before power control has had a chance to reduce the
// sender's transmit power. The stall will only occur when the device has
// performed an inquiry since it was last reset.
// 
// This patch assumes that PSKEY_RX_ATTEN_BACKOFF and
// PSKEY_RX_ATTEN_UPDATE_RATE remain set to their default values.
// 
// B-5329
// An issue has been identified in BlueCore ROM parts which are used in a
// configuration such that the host's clock request is an input on PIO[3]
// and is combined internally with BlueCore's clock request logic; the
// resulting composite clock request being an output on PIO[2]. This is the
// behavior enabled by setting PSKEY_CLOCK_REQUEST_ENABLE to 3.
// 
// Unfortunately, the clock request output will glitch to "inactive" (0)
// for around 3uS, around 200ms after reset. This may cause issues within
// the host system, because a typical use case will be to boot the Bluecore
// device, download host-specific configuration data (such as a Bluetooth
// address) and then perform a warm reset.
// 
// This patch will restore the correct behaviour, which is that the clock
// request output from the chip will be placed into a Hi-Z state for the
// duration of the reset, to be pulled by an external resistor, and will
// not be actively driven low.
// 
// This patch is commented-out by default in this patch file, because not
// every application uses this clock request functionality.  To enable the
// patch, uncomment the patch:
// 
// 	patch patch_38, PSKEY_PATCH38 (0x00bc, 188) 
// 
// And, using the host software, also set PSKEY_CLOCK_REQUEST_ENABLE
// (0x246, 582) to zero.  In effect, the patch disables the code wired to
// PSKEY_CLOCK_REQUEST_ENABLE and replaces it with code which asserts the
// clock requst signal at a later point in the chip boot sequence.  The
// drive direction of the clock request pin is thereby set up correctly
// before the drive to the pin is enabled, thus removing the glitch.  
// 
// B-6002, B-6334
// When BlueCore is on link with EDR eSCO but not EDR ACL, EDR eSCO packets are
// not transmitted or received correctly. This is caused by an oversight in the
// firmware, which fails to enable certain hardware required for EDR. The
// supplied patch remedies this. Also, BlueCore does not disable the hardware
// when an EDR eSCO or ACL link is disconnected, which uses power unnecessarily.
// The patch also remedies this.
// 
// B-4509
// When Bluecore is configured to use the H4DS host transport, it is 
// possible for the host interface to stall. This happens following certain
// patterns of UART activity which can cause Bluecore to enter an infinite
// cycle of sending You-May-Sleep and Wake-Up messages. This patch prevents
// the problem from occurring.
// 
// NOTE: This patch, PSKEY_PATCH37 (0x00BB), is only applicable to the H4DS
// host transport. The patch need not be applied when using any other host
// transport.
// 
// B-21798
// When we receive an inbound connection from a device that we think is already
// connected we drop the old connection and use the new one in preference. This
// is because typically what has happened is the old device has been reset and
// has reconnected before the supervision timeout for the old connection.
// 
// Unfortunately, when this happens, we don't freeze the old HCI handle (see
// PSKEY_HCI_HANDLE_FREEZE_PERIOD). If the host writes to the old handle after
// we've disconnected it but, presumably, before the host has processed the
// disconnection complete event, then the chip will panic.
// 
// This patch ensures that the old handle is frozen correctly as it would be
// after a real supervision timeout.
// 
// B-19265:
// Occasionally, after the chip performs a self-calibration procedure, it
// can leave part of the radio hardware in a slightly odd state. This means
// that the next packet we transmit can contain the wrong data. Typically,
// this data is from further ahead in the data stream, but it could also be
// from earlier in the data stream, from a different data stream or garbage.
// 
// This fix is to set up the hardware better at the start of a calibration
// to make sure that the state is consistent at the end.
// 
// B-19706:
// The firmware can get into a state whereby it transmits packets at the
// wrong time. This typically happens when mixing packets at different
// power levels. Specifically, a low power (short range) basic rate link
// may be affected if there's a high power basic rate link, any EDR link
// or a page, inquiry, page scan or inquiry scan recently.
// 
// The problem was caused by a cache of a timing calculation being incorrectly
// marked as valid when switching between the different power levels. It should
// have been marked as invalid and the fix is simply to update it correctly.
// 
// For most devices the effect is pretty much harmless. This problem has been
// observed only when we are master. Our transmit timing will jitter out of
// spec but within the 10 us timing window the slave allows. However, if the
// basic rate link is at very low power, the jitter could be more than 10 us.
// If the slave doesn't implement active mode receive window widening, it
// could lose us completely. CSR slaves always implement active mode receive
// window widening so don't see this problem. Active mode receive window
// widening is also explicitly recommended in later versions of the BT spec.
// 
// B-11615
// This patch is B-11615. It fixes B-6692 and B-11614. It applies to Bluecore
// chips configured to use the BCSP host interface only.
// 
// B-11615 fixes B-6692
// BC4 ROM build 1958, when configured to use a UART host transport with
// a baud rate greater than 1Mbps, may occasionally drop a byte of inbound
// UART data. This patch solves the problem by disabling shallow sleep when
// the chip is configured to use a baud rate greater than 1Mbps.
// 
// B-11615 fixes B-11614
// BC4 ROM build 1958, when configured to use the BCSP host transport may
// occasionally enter a power saving mode (deep sleep) during the transmission
// of a UART packet to the host. This can sometimes prevent the Bluecore from
// transmitting any further UART data to the host.
// 
// The code associated with this bug will be commented out until needed. 
// This patch should only be applied if the application is using the BCSP 
// host transport.



//////////////////////////////////////////////////////////////////////////////
// patch_spare5, PSKEY_PATCH34 (0x00b8, 184)
uint16 csr_b1958_patch_34_pskey = 0x00b8;
uint16 csr_b1958_patch_34_data[] = {
       0x0002, 0x8416, 0x031b, 0x4216, 0x22f4, 0x4316, 0x0684, 0x1ff0, 
       0x9015, 0x08c4, 0x16f0, 0x9511, 0x9515, 0xfdc4, 0x9525, 0x9015, 
       0x08b4, 0x9025, 0x9715, 0x01b4, 0x9725, 0xff00, 0x6f15, 0xfdc4, 
       0xff00, 0x6f25, 0xff00, 0x5315, 0x20b4, 0xff00, 0x5325, 0x9521, 
       0x0118, 0xff2b, 0xff0e, 0x8400, 0x1218, 0x00e2, 0x0113, 0x3f30, 
       0xe721, 0x0118, 0xff2b, 0xff0e, 0x8400, 0x1918, 0x00e2, 0x5d46 };

//////////////////////////////////////////////////////////////////////////////
// patch_spare4, PSKEY_PATCH33 (0x00b7, 183)
uint16 csr_b1958_patch_33_pskey = 0x00b7;
uint16 csr_b1958_patch_33_data[] = {
       0x0003, 0x3041, 0x0014, 0xfe27, 0x0114, 0xff27, 0x0218, 0xff2b, 
       0xff0e, 0x3000, 0x4418, 0x00e2, 0x63c2 };

//////////////////////////////////////////////////////////////////////////////
// patch_spare6, PSKEY_PATCH35 (0x00b9, 185)
uint16 csr_b1958_patch_35_pskey = 0x00b9;
uint16 csr_b1958_patch_35_data[] = {
       0x0002, 0xb6bf, 0x0117, 0xb800, 0xe184, 0x07f4, 0xb800, 0xf184, 
       0x04f4, 0xb800, 0x1784, 0x12f0, 0xe300, 0xb519, 0x06f4, 0x1412, 
       0x15b2, 0x0cf0, 0x001a, 0xfcf0, 0xfc3c, 0x0014, 0x0327, 0x0118, 
       0xff2b, 0xff0e, 0x4400, 0x7818, 0x00e2, 0x043c, 0xfe0e, 0xffe3, 
       0x8cd3 };

//////////////////////////////////////////////////////////////////////////////
// patch_bc_boot, PSKEY_PATCH1 (0x0097, 151)
uint16 csr_b1958_patch_1_pskey = 0x0097;
uint16 csr_b1958_patch_1_data[] = {
       0x045c, 0x032b, 0x020a, 0x0014, 0x0027, 0x2100, 0xb434, 0x0018, 
       0x012b, 0x010e, 0xf100, 0x4018, 0x009e, 0x0084, 0x10f4, 0xf225, 
       0xf219, 0x0116, 0x0012, 0x001b, 0x003b, 0x003b, 0xfd00, 0x7a38, 
       0x0022, 0x0126, 0xf215, 0xa000, 0xfe54, 0x0226, 0x0017, 0x0134, 
       0x0027, 0x0884, 0xe3fc, 0x2100, 0xbc14, 0x0018, 0x012b, 0x010e, 
       0xf100, 0x4018, 0x009e, 0x0084, 0x08f4, 0x1410, 0x0123, 0x010e, 
       0xa000, 0x0054, 0x0127, 0x019f, 0x020e, 0x043c, 0xffe3, 0x2a15 };

//////////////////////////////////////////////////////////////////////////////
// patch_spare7, PSKEY_PATCH36 (0x00ba, 186)
uint16 csr_b1958_patch_36_pskey = 0x00ba;
uint16 csr_b1958_patch_36_data[] = {
       0x0001, 0x03f3, 0x1414, 0xde00, 0xbc25, 0xe000, 0x6b15, 0xa000, 
       0xe354, 0xde00, 0xbd25, 0x0114, 0xfe00, 0x8c25, 0x0400, 0x3e14, 
       0xfe00, 0x8d25, 0xfe00, 0x8e15, 0x3134, 0xfe00, 0x8e25, 0x0018, 
       0xff2b, 0xff0e, 0x0400, 0xf918, 0x00e2, 0xff2b, 0x0084, 0x11ec, 
       0x9811, 0x4000, 0x00c0, 0xe921, 0x0010, 0x9025, 0x9815, 0x4000, 
       0x00c4, 0xe9d5, 0x05f0, 0x0130, 0x4000, 0x0180, 0xf8fc, 0xffe3, 
       0x0008, 0x0000, 0xffe3, 0x0114, 0xfe00, 0x8c25, 0x0400, 0xf314, 
       0xfe00, 0x8d25, 0xfe00, 0x8e15, 0x3154, 0xfe00, 0x8e25, 0xde00, 
       0xbd19, 0xa000, 0x1338, 0x0814, 0x0026, 0xffe3, 0x389c };

//////////////////////////////////////////////////////////////////////////////
// patch_spare3, PSKEY_PATCH32 (0x00b6, 182)
uint16 csr_b1958_patch_32_pskey = 0x00b6;
uint16 csr_b1958_patch_32_data[] = {
       0x0001, 0x23bf, 0xde00, 0x9f15, 0x2384, 0x04e4, 0xff00, 0xffc0, 
       0x03e0, 0x0100, 0x00b0, 0xe721, 0xe515, 0x0018, 0xff2b, 0xff0e, 
       0x2400, 0xd718, 0x00e2, 0x73b8 };

//////////////////////////////////////////////////////////////////////////////
// patch_bg_usleep, PSKEY_PATCH4 (0x009a, 154)
// patch for B-11615
uint16 csr_b1958_patch_4_pskey = 0x009a;
uint16 csr_b1958_patch_4_data[] = {
       0xfe0a, 0xff2b, 0xfe3c, 0xdd00, 0x6015, 0x0184, 0x2df0, 0x5d15, 
       0x1000, 0x0084, 0x04fc, 0x0014, 0xde00, 0xb425, 0xe700, 0xa615, 
       0x93c5, 0x01c4, 0x15f4, 0xe700, 0xa815, 0x4ed5, 0xfa25, 0xe700, 
       0xa715, 0x4dd5, 0xfab5, 0x0cf0, 0xb415, 0xe700, 0xa955, 0x0884, 
       0x13fc, 0x0014, 0x0027, 0x000e, 0x5700, 0x4d18, 0x009e, 0x9315, 
       0xe700, 0xa625, 0x4d15, 0xe700, 0xa725, 0x4e15, 0xe700, 0xa825, 
       0xb415, 0xe700, 0xa925, 0x023c, 0xfe0e, 0xffe3, 0x83b4 };

//////////////////////////////////////////////////////////////////////////////
// patch_38, PSKEY_PATCH38 (0x00bc, 188)
uint16 csr_b1958_patch_38_pskey = 0x00bc;
uint16 csr_b1958_patch_38_data[] = {
       0x9511, 0xfdc0, 0x9515, 0x9521, 0x9711, 0x4000, 0x00b0, 0x9721, 
       0x6111, 0x04b0, 0x6121, 0xff00, 0x5211, 0x01b0, 0xff00, 0x5221, 
       0x9525, 0x00e2, 0xdb18 };

//////////////////////////////////////////////////////////////////////////////
// patch_spare2, PSKEY_PATCH31 (0x00b5, 181)
uint16 csr_b1958_patch_31_pskey = 0x00b5;
uint16 csr_b1958_patch_31_data[] = {
       0x0001, 0x1e07, 0x0010, 0x0521, 0xde00, 0x6819, 0x2f12, 0xde00, 
       0x6719, 0x3016, 0x03f4, 0x3116, 0x02f0, 0x2f22, 0xde00, 0x6715, 
       0xde00, 0x6811, 0x0018, 0xff2b, 0xff0e, 0x1e00, 0x0b18, 0x00e2, 
       0xdfa5 };

//////////////////////////////////////////////////////////////////////////////
// patch_37, PSKEY_PATCH37 (0x00bb, 187)
uint16 csr_b1958_patch_37_pskey = 0x00bb;
uint16 csr_b1958_patch_37_data[] = {
       0x0002, 0x0ec1, 0x0018, 0xff2b, 0xff0e, 0x6800, 0xa718, 0x009e, 
       0x023c, 0xfe0e, 0xffe3, 0xead4 };

//////////////////////////////////////////////////////////////////////////////
// patch_radiotest_tx_start, PSKEY_PATCH17 (0x00a7, 167)
uint16 csr_b1958_patch_17_pskey = 0x00a7;
uint16 csr_b1958_patch_17_data[] = {
       0x0513, 0x00f6, 0xff00, 0x5311, 0xde00, 0x9f15, 0x2384, 0x04e4, 
       0xff00, 0xffc0, 0x03e0, 0x0100, 0x00b0, 0xff00, 0x5321, 0x00e2, 
       0xb2cd };

//////////////////////////////////////////////////////////////////////////////
// patch_lc_rx_hw_set, PSKEY_PATCH25 (0x00af, 175)
uint16 csr_b1958_patch_25_pskey = 0x00af;
uint16 csr_b1958_patch_25_data[] = {
       0x0915, 0x0184, 0x00f2, 0x0214, 0x0925, 0x00e2, 0xf019 };

//////////////////////////////////////////////////////////////////////////////
// patch_spare1, PSKEY_PATCH30 (0x00b4, 180)
uint16 csr_b1958_patch_30_pskey = 0x00b4;
uint16 csr_b1958_patch_30_data[] = {
       0x0002, 0xb264, 0x1414, 0x0118, 0xff2b, 0xff0e, 0xb200, 0x6718, 
       0x00e2, 0x27ff };
