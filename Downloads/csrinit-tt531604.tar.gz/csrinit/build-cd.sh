#!/bin/sh
# call make on Christians machine

export PATH="/opt/crosstool/arm-softfloat-linux-gnu/gcc-3.4.1-glibc-2.3.3/bin:$PATH"
export ARCH=arm-softfloat-linux-gnu-
export CROSS_COMPILE=arm-softfloat-linux-gnu-
make
