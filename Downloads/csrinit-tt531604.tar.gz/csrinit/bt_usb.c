/* initialise BCxROM over usb using libusb */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <usb.h>

#include "ubcsp.h"

int verbose = 0;

struct usb_dev_handle *
find_bcx_usb_device()
{
	struct usb_bus *busses;
	struct usb_bus *bus;
	struct usb_dev_handle *udev;

	busses = usb_get_busses();

  for (bus = usb_busses; bus; bus = bus->next) {
    if (bus->root_dev) {
      struct usb_device *dev;

      for (dev = bus->devices; dev; dev = dev->next) {
			  udev = usb_open(dev);
			  if (!udev) {
					printf("usb_open() failed\n");
			  	return NULL;
				} else {
					if ((dev->descriptor.idVendor == 0x0a12) && (dev->descriptor.idProduct == 0x0001))
						return udev;
					if ((dev->descriptor.idVendor == 0x1390) && (dev->descriptor.idProduct == 0x4d4a)) {
						printf("TomTom USB device found\n");
						return udev;
					}
			  }
      }
    }
  }
  if (usb_busses)
		return NULL;	
  else
	printf("no usb bus found\n");
  return NULL;
}

static struct usb_dev_handle *u_dev = NULL;


int open_usb_conn()
{
	int i;

	/* usblib overhead, browse /proc system etc */
	usb_init();
	usb_find_busses();
	usb_find_devices();
	
	i = 300; /* * 10 msec */
	while (1) {	
		u_dev = find_bcx_usb_device();
		if (u_dev == NULL) {
			usleep(100000); /* wait 10 msec */
			i--;
			if (i < 0) {
				printf("usb_conn() timeout\n");
				u_dev = NULL;
				return -1;	
			}
		} else
			break;
	}
	if (!u_dev) {
		return -1;
	} else {
		/* set conf 1, interface 2 with altset = 0 */
		if (usb_set_configuration(u_dev, 1) < 0) {
			printf("can't set configuration\n");
			return -1;
		}
		if (usb_claim_interface(u_dev, 0) < 0) {
			printf("can't claim interface 0\n");
			return -1;
		}
		if (usb_claim_interface(u_dev, 1) < 0) {
			printf("can't claim interface 1\n");
			return -1;
		}
		if (usb_set_altinterface(u_dev, 0) < 0) {
			printf("can't set alt setting\n");
			return -1;
		}
		
		/* start talking HCI now */
	}
	return 0;
}

int	usb_receive_packet(struct ubcsp_packet *receive_packet)
{
	unsigned char hci_header[2];

	usb_bulk_read(u_dev, 1, &hci_header[0], 2, 100);
	receive_packet->length = hci_header[1];
	usb_bulk_read(u_dev, 1, receive_packet->payload, hci_header[1], 100);
	return hci_header[1];
}

int send_usb_packet(unsigned char *data, int len)
{
	usb_control_msg(u_dev, 0x20, 0x00, 0x0000, 0x0000, data, len, 100);
	return 0;
}

void close_usb_conn()
{
	if (u_dev) {
		usb_release_interface(u_dev, 0);
		usb_close(u_dev);
	}
}
