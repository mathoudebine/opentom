/*
 * CSR BlueCore ROM version initialisation
 * Copyright by TomTom BV
 * Written by Christian Daniel 2004 with some inspiration from
 * OpenBT - copyright by Axis Communication AB
 * pskey - copyright by Fabrizio Gennari
 * published under GPLv2 or newer
 * 
 * This file is the main source code of the CSR Bluetooth chip initialisation
 * which is called on the device when Bluetooth is enabled.
 * Hardware specific functionality is initiated via command line arguments.
 * For changes please contact connectivity team!
 * 
 * Below version management. Change only in confluence with connectivity team.
 * 
 */
#define version   4
#define revision  7
/* 
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>
#include <err.h>
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>

#ifndef Nashville_kernel_2_6_23_arm9
#include <linux/serial.h>
#else
#include <linux/gpio_ioctl.h>
#endif

#include "ubcsp.h"
#ifdef SUPPORT_USB
#include "bt_usb.h"
#endif

// include patches here
#include "csr_b1958_patches.h"
#include "csr_b3164_patches.h"

#define sizeof_patch(data)   sizeof(data)/sizeof(uint16)

#define streq(s1, s2) (strcmp(s1, s2) == 0)

#undef  RFBOARD_RESET

int debug = 0;

#define DBG(fmt, arg...) if (debug){printf(fmt ,##arg);fflush(stdout);} else {}

// enable to use CSR Bluetooth chip enhanced power table
int   use_enhanced_power_table = 0; // false
// (csrinit state 29)

// later chip revisions do not need frequency trim
int   use_frequency_trim_value = 1; // true
// (csrinit state 33)

// disable PS key protection to be able to change pskeys later */
int   skip_pskey_protection = 0; // false
// (csrinit state 97)

// rider adds
// - making sure cpu clock will not in to deep a power down mode during audio handling 
//  (csrinit state 14)
// - calc real baudrate 
int   calc_real_baudrate = 0; // false
int   baudrate = -1;
int   no_deep_sleep_during_audio_handling = 0; // false

// special commands
int warm_halt = 0;
int warm_reset = 0;
int disable_tx = 0;
int enable_tx = 0;
int ignore_unknown_bd_address = 0;   /* This flag indicates whether a command
                                        line Bluetooth address which is not
                                        recognized should be ignored and used
                                        anyhow. */

int ana_trim = -1;
int btAddrSpecifiedOnCommandLine = 0;
uint8 bdAddress[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

enum BCCMD_MODE {
    BCCMDMODE_H4,
    BCCMDMODE_UBCSP,
    BCCMDMODE_USB
};

int mode = BCCMDMODE_UBCSP;
int crystal_freq = 0;
int ext_clock = 0; /* set of no ana_ftrim possible */
int detected_chiprevision = 0x00;
int csr_build_id = 0;

/* sending any powertable seems to crash CSR ROM in some cases */
#define SEND_POWERTABLE

/******************************************************************************/

/* file descriptor for serial port */
int serialfd = -1;

/* Real baudrate, not the one it's closest to. */
int real_baudrate = -1;


static inline int divrnd(int nom, int den);

static int calc_real_rate(int rate)
{
  int res = rate;

#ifndef S3C64XX_TARGET    
  const char clocks[] = "/proc/clocks";
    FILE *fp = NULL;
    int pclk;
    char buf[128];
    int div;

    /* Read PCLK from /proc/clocks */
    if ((fp = fopen(clocks, "r")) == NULL) {
        warn("Could not open %s", clocks);
    } else {
        for (pclk = 0; !feof(fp) && !ferror(fp);) {
            if (fgets(buf, sizeof buf, fp) == NULL)
                break;
            if (sscanf(buf, "pclk: %d", &pclk) == 1)
                break;
        }
        if (ferror(fp)) {
            warn("Could not read %s", clocks);
        } else if (pclk == 0) {
            warnx("Could not find pclk in %s", clocks);
        } else if (pclk < 1000000 || pclk > 1000000000) {
            warnx("Insane pclk %d in %s", pclk, clocks);
        } else {
            /* The baud rate divisor is determined by: PCLK / (16 * rate) */
#ifndef Nashville_kernel_2_6_23_arm9
            div = divrnd(pclk, 16 * rate);
#else
            div = divrnd(pclk, rate);
#endif
            /* Therefore, the real rate is PCLK / (16 * divisor) */
#ifndef Nashville_kernel_2_6_23_arm9
            res = divrnd(pclk, 16 * div);
#else
            res = divrnd(pclk, div);
#endif
            DBG("rate %d, pclk %d, div %d -> real rate %d\n",
                rate, pclk, div, res);
        }
        fclose(fp);
    }
#endif // ifndef S3C64XX_TARGET
    return res;
}

/*
 * open serial port with following parameters: xxxxxx baud, 8E1, no flow control
 */
int serial_open(const char *devname, speed_t speed)
{
    int fd;
    struct termios ti;
#ifndef Nashville_kernel_2_6_23_arm9
    struct serial_struct serinfo;
#endif
    unsigned long arg;

    if((fd = open(devname, O_RDWR | O_NOCTTY)) < 0) {
        warn("Could not open serial port %s", devname);
        return -1;
    }
    tcflush(fd, TCIOFLUSH);

    if(tcgetattr(fd, &ti) < 0) {
        warn("Could not get serial port attributes");
        goto failed;
    }

    /* be sure that serial port is configured correctly */
    cfmakeraw(&ti);
    ti.c_cflag |=  CLOCAL;
    ti.c_cflag &= ~CRTSCTS;
    ti.c_cflag |=  PARENB;
    ti.c_cflag &= ~PARODD;
    ti.c_cflag &= ~CSIZE;
    ti.c_cflag |=  CS8;
    ti.c_cflag &= ~CSTOPB;

    /* one byte at a time, no timer */
    ti.c_cc[VMIN] = 1;
    ti.c_cc[VTIME] = 0;

    cfsetspeed(&ti, speed);

    if(tcsetattr(fd, TCSANOW, &ti) < 0) {
        warn("Could net set serial port attributes");
        goto failed;
    }

    /* non blocking i/o is needed for the state machines below */
    arg = fcntl(fd, F_GETFL, 0);
    arg |= O_NONBLOCK;
    if(fcntl(fd, F_SETFL, arg) < 0) {
        warn("Could not set serial port to nonblocking");
        goto failed;
    }

#ifndef Nashville_kernel_2_6_23_arm9
    if (!calc_real_baudrate)
    {
        if( ioctl( fd, TIOCGSERIAL, &serinfo ) != 0 )
        {
            warn( "Could not get serial port info" );
            goto failed;
        }
        if (!serinfo.custom_divisor)
        {
#ifndef S3C64XX_TARGET        
#ifndef Nashville_kernel_2_6_23_arm9
            fprintf(stderr, "Failed to retrieve serial port info from kernel. Please fix kernel!\n");
            goto failed;
#else
            fprintf(stderr, "Failed to retrieve serial port info from kernel. Please fix kernel! Now default taken.\n");
            /* default 921600 */
            real_baudrate = 921600;
#endif
#else
            real_baudrate = baudrate;
#endif//S3C64XX_TARGET 
        }
        else
        {

            real_baudrate = serinfo.baud_base/serinfo.custom_divisor;
        }
  }
    else
#endif
        real_baudrate = calc_real_rate(baudrate);

    return fd;

failed:
    close(fd);
    return -1;
}

/*
 * send a single byte to the serial port - being called externally from ubcsp
 */
void put_uart(uint8 ch)
{
    write(serialfd, &ch, 1);
}

/*
 * get a byte from the serial port - being called externally from ubcsp
 */
uint8 get_uart(uint8 *ch)
{
    int res;

    res = read(serialfd, ch, 1);
    return res > 0 ? res : 0;
}

/******************************************************************************/

#ifdef RFBOARD_RESET

#define GPS_DRIVER_MAGIC    'U'
#define IOW_GPS_ON      _IO(GPS_DRIVER_MAGIC, 1)
#define IOW_GPS_OFF     _IO(GPS_DRIVER_MAGIC, 2)
#define IOW_GPS_RESET   _IO(GPS_DRIVER_MAGIC, 3)

/*
 * resets the RF board by cycling the power and asserting the nReset line
 */
void reset_rf_board()
{
    int fd;

    DBG("resetting RF board\n");
    fd = open("/dev/gps", O_RDWR);
    ioctl(fd, IOW_GPS_OFF, NULL);
    sleep(1);
    ioctl(fd, IOW_GPS_ON, NULL);
    ioctl(fd, IOW_GPS_RESET, NULL);
    sleep(1);
    close(fd);
}

#endif /* RFBOARD_RESET */

/******************************************************************************/

/* HCI command packet header */
struct cmd_pkt {
    uint16 opcode;
    uint8 len;
    uint8 data[256];
} __attribute__((packed));

/* CSR proprietary message header */
struct csr_msg {
    uint8 desc;
    uint8 data[0];
} __attribute__((packed));

/* CSR variable set- or get-header */
struct csr_bccmd {
    uint16 type;
    uint16 len;
    uint16 seq;
    uint16 id;
    uint16 status;
    uint16 data[0];
} __attribute__((packed));

/* CSR ps key access header */
struct csr_bccmd_ps {
    uint16 ps_key;
    uint16 ps_len;
    uint16 unused;
    uint16 ps_val[0];
} __attribute__((packed));

/* loads of magic defines */
#define CMD_HDR_LEN        3
#define HCI_HDR_LEN        1
#define BCSP_CMD_CHN       5
#define MANUFACTURER_SPEC  0x3f
#define CSR_CH_ID_BCCMD    0x02

#define CSR_MSGTYPE_GETREQ 0x0000
#define CSR_MSGTYPE_SETREQ 0x0002
#define CSR_CMD_BUILD_ID   0x2819
#define CSR_CMD_CHIPVER    0x281a
#define CSR_CMD_CHIPREV    0x281b
#define CSR_CMD_PS_SIZE    0x3006
#define CSR_CMD_PS         0x7003

// commands
#define CSR_WARM_RESET     0x4002
#define CSR_WARM_HALT      0x4004
#define CSR_ENABLE_TX      0x4007
#define CSR_DISABLE_TX     0x4008

#define CSR_STATUS_OK      0x0000

#define CSR_PS_ANA_FREQ                     0x01fe
#define CSR_PS_ANA_FTRIM                    0x01f6
#define CSR_PS_TX_OFFSET_HALF_MHZ           0x0217
#define CSR_PS_CLASSOFDEVICE                0x0003
#define CSR_PS_FEATURES                     0x00EF
#define CSR_PS_COUNTRYCODE                  0x0002
#define CSR_PS_HOST_INTERFACE               0x01f9
#define CSR_PS_LC_DEFAULT_TX_POWER          0x0021
#define CSR_PS_UART_BAUD_RATE               0x01be
#define CSR_PS_UART_CONFIG_FLOW_CTRL_EN     0x03fe
#define CSR_PS_AMUX_B                       0x022c
#define CSR_PS_PATCH_22                     0x00ac
#define CSR_PS_TXRX_PIO_CONTROL             0x0209
#define CSR_PS_BDADDR                       0x0001
#define CSR_PS_BCCMD_SECURITY_ACTIVE        0x01fd
#define CSR_PS_LC_POWER_TABLE               0x001e
#define CSR_PS_LC_ENHANCED_POWER_TABLE      0x0031
#define CSR_PS_HOSTIO_MAP_SCO_PCM           0x01ab
#define CSR_PS_USB_VENDORID                 0x02be
#define CSR_PS_USB_PRODUCTID                0x02bf
#define CSR_PS_HOSTIO_SCO_HCI_THRESHOLDS    0x01bc
#define CSR_PS_MAX_SCOS                     0x000e

uint16 ps_uart_baudrate_value;

#define hci_put_opcode(ocf, ogf) (cpu_to_le16(((ocf) & 0x03ff) | \
    ((ogf) << 10 & 0xfc00)))

#define GET_BITS(var, bit, bits) (((var) >> (bit)) & ((1UL << (bits)) - 1))
#define SET_BITS(var, bit, bits, x)                    \
    do {                                \
        (var) = ((var) & ~(((1UL << (bits)) - 1) << (bit))) |    \
        (((x) & ((1UL << (bits)) - 1)) << (bit));        \
    } while (0)

#define CSR_GET_LAST(msg)    GET_BITS((msg)->desc, 7, 1)
#define CSR_SET_LAST(msg, x)    SET_BITS((msg)->desc, 7, 1, (x) != 0)
#define CSR_SET_FIRST(msg, x)    SET_BITS((msg)->desc, 6, 1, (x) != 0)
#define CSR_GET_CH_ID(msg)    GET_BITS((msg)->desc, 0, 6)
#define CSR_SET_CH_ID(msg, id)    SET_BITS((msg)->desc, 0, 6, id)

#if (__BYTE_ORDER == __LITTLE_ENDIAN)
#    undef __BIG_ENDIAN
#endif
#if (__BYTE_ORDER == __BIG_ENDIAN)
#    undef __LITTLE_ENDIAN
#endif

#ifdef __LITTLE_ENDIAN
#    define cpu_to_le16(x) (x)
#    define cpu_to_le32(x) (x)
#    define cpu_to_be16(x) htons((x))
#    define cpu_to_be32(x) htonl((x))
#else
#    define cpu_to_be16(x) (x)
#    define cpu_to_be32(x) (x)
    extern inline __u16 cpu_to_le16(__u16 x) { return (x<<8) | (x>>8); }
    extern inline __u32 cpu_to_le32(__u32 x) { return ((x>>24) |
        ((x>>8)&0xff00) | ((x<<8)&0xff0000) | (x<<24)); }
#endif

#define le16_to_cpu(x)  cpu_to_le16(x)
#define le32_to_cpu(x)  cpu_to_le32(x)
#define be16_to_cpu(x)  cpu_to_be16(x)
#define be32_to_cpu(x)  cpu_to_be32(x)

char *csr_chipver[] = {
    "BlueCore01a",
    "BlueCore01b",
    "BlueCore2-External, BlueCore2-ROM (ST or TSMC)",
    "BlueCore3-MM, -ROM, -Flash or BlueCore4-External, -ROM",
    "BlueCore unknown"
};

struct csr_chiprev {
    uint16 value;
    char *desc;
};

#define CHIPREVISION_BLUECORE3_ROM 0x15
#define CHIPREVISION_BLUECORE4_ROM 0x30

struct csr_chiprev csr_chiprev[] = {
    {0x64, "BlueCore01b, engineering sample (ES) version"},
    {0x65, "BlueCore01b, production version"},
    {0x89, "BlueCore2-External, version a"},
    {0x8a, "BlueCore2-External, version b"},
    {0x28, "BlueCore2-ROM"},
    {0x43, "BlueCore3-MM"},
    {CHIPREVISION_BLUECORE3_ROM, "BlueCore3-ROM"},
    {0xe2, "BlueCore3-Flash"},
    {0x26, "BlueCore4-External"},
    {CHIPREVISION_BLUECORE4_ROM, "BlueCore4-ROM"},
    {0x00, "BlueCore unknown"}
};

/* Enhanched power table, any value set in the PSKEY_LC_POWER_TABLE are ignored; the
   two tables are mutually exclusive. The old csrinit uses this power table */
uint16 psset_0031[] = {
  0x0400, 0x0000, 0x3f00, 0x4500, 0xe800,
  0x0900, 0x0000, 0x3f00, 0x4700, 0xec00,
  0x0f00, 0x0000, 0x3f00, 0x4a00, 0xf000,
  0x1600, 0x0000, 0x3f00, 0x4d00, 0xf400,
  0x1600, 0x0000, 0x3f00, 0x4d00, 0xf400,
  0x1600, 0x0000, 0x3f00, 0x4d00, 0xf400,
  0x1600, 0x0000, 0x3f00, 0x4d00, 0xf400,
  0x1600, 0x0000, 0x3f00, 0x4d00, 0xf400 };


struct power_entry {
    uint8 external_pa;
    uint8 internal_pa;
    uint8 reserved;
    int8 tx_dbm;
} __attribute__((__packed__));

#define MAX_PT_ENTRIES 16

struct btcal_flash {
    uint16 crystal_trim;
    union {
        uint32 raw;
        struct power_entry u;
    } power_table[MAX_PT_ENTRIES + 1];
} __attribute__((__packed__));

struct btcal_flash btcal_flash;

int btcal_sanity_check()
{
    int i;
    int last_dbm;
    int err;
    const int min_step_size = 2;
    const int max_step_size = 8;
    if (btcal_flash.power_table[0].raw == 0x00000000) {
        DBG("sanity check: powertable[0] is 0x00000000, must be 0xffffffff to indicate no powertable\n");
        return -1;
    }
    if (btcal_flash.power_table[0].u.tx_dbm >= 4) {
        DBG("sanity check: first entry powertable[0].tx_dbm %d (0x%02x) must be < 4 dBm\n",
            btcal_flash.power_table[0].u.tx_dbm, (uint8)btcal_flash.power_table[0].u.tx_dbm);
        return -1;
    }
    last_dbm = 0; // will not be used, 
    for (i=0; i<(MAX_PT_ENTRIES+1); i++) {
        err = 0;
        /* check if entry is end of list */
        if ((i > 0) && (btcal_flash.power_table[i].raw == 0x00000000)) {
            DBG("sanity check: proper 0x00000000 end of table at [%d]\n",i);
            if (i == 1) {
                DBG("sanity check: powertable is only one entry long, BAD\n");
                return -1;
            }
            return 0;
        }
        if (btcal_flash.power_table[i].raw == 0xffffffff) {
            DBG("sanity check: raw 0xffffffff powertable[%d] entry found, table must be 0x00000000 terminated\n",i);
            return -1;
        }
        if (btcal_flash.power_table[i].u.internal_pa > 0x3f) {
            DBG("sanity check: powertable[%d].internal_pa 0x%02x must be below 0x3f\n",i,btcal_flash.power_table[i].u.internal_pa);
            err = -1;
        }
        if (btcal_flash.power_table[i].u.external_pa != 0x00) {
            DBG("sanity check: powertable[%d].external_pa 0x%02x must be 0x00, cant support external amp\n",i,btcal_flash.power_table[i].u.external_pa);
            err = -1;
        }
        if (btcal_flash.power_table[i].u.reserved != 0x00) {
            DBG("sanity check: powertable[%d].reserved 0x%02x must be 0x00, invalid entry\n",i,btcal_flash.power_table[i].u.reserved);
            err = -1;
        }
        if (i > 0) {
            // since last_dbm is initially not set
            if (btcal_flash.power_table[i].u.tx_dbm <= (last_dbm + min_step_size)) {
                DBG("sanity check: powertable[%d] == %d (%02x), must be at least 2 dBm higher as previous entry\n",i,btcal_flash.power_table[i].u.tx_dbm,(uint8)btcal_flash.power_table[i].u.tx_dbm);
                err = -1;
            }
            if (btcal_flash.power_table[i].u.tx_dbm >= (last_dbm + max_step_size)) {
                DBG("sanity check: powertable[%d] == %d (%02x), can be max 8 dBm higher as previous entry\n",i,btcal_flash.power_table[i].u.tx_dbm,(uint8)btcal_flash.power_table[i].u.tx_dbm);
                err = -1;
            }
        }
        if (btcal_flash.power_table[i].u.tx_dbm < -30) {
            DBG("sanity check: WARNING powertable[%d] %d (%02x) is below -30 dBm, out of spec\n",i,btcal_flash.power_table[i].u.tx_dbm,(uint8)btcal_flash.power_table[i].u.tx_dbm);
        }
        // update last_sdm
        last_dbm = btcal_flash.power_table[i].u.tx_dbm;
    }
    if (err == -1)
        return -1;
    DBG("sanity check: too many entries (%d), table must be 0x00000000 terminated\n",i);
    return -1;
}


/* 
 * This patch (22) is not intended for CSR builds above 1593.
 */
unsigned char patch_22[37*2] = {
0x00,0x00, 0x2b,0xff, 0x14,0x00, 0x00,0xff, 0x25,0x7b, 0x15,0x80, 0x00,0x10, 0xb4,0x00,
0x25,0x80, 0x14,0x04, 0x00,0xff, 0x25,0x79, 0x00,0x03, 0x14,0x20, 0x21,0xe3, 0x34,0xff,
0xf0,0xff, 0x00,0x45, 0x14,0xac, 0x00,0xff, 0x25,0x7b, 0x00,0x3f, 0x14,0x80, 0x34,0xff,
0xf0,0xff, 0x14,0x01, 0x00,0xff, 0x25,0x79, 0x14,0x00, 0x00,0xff, 0x25,0x7b, 0x15,0x80,
0x00,0xf0, 0xc4,0xff, 0x25,0x80, 0xe3,0xff, 0x00,0x00 
};



/* command sequence counter */
unsigned short csr_seq = 0;

/* sending state */
int state;

/* result of last PS key size message */
int pskey_size = 0;

/******************************************************************************/

/*
 * process an event received from the CSR module
 */
void process_csr_event(struct csr_bccmd *cmd)
{
    int i;
/*
    
    DBG("type:    %d\n", cmd->type);
    DBG("len:     %d\n", cmd->len);
    DBG("seq:     %d\n", cmd->seq);
    DBG("id:      %04x\n", cmd->id);
    DBG("status:  %d\n", cmd->status);
    DBG("data:    ");
    for(i = 0; i < cmd->len - 5; i++)
    {
        DBG("%04x ", cmd->data[i]);
    }
    DBG("\n");
*/
    if(cmd->status != CSR_STATUS_OK)
        fprintf(stderr, "!!!! CSR MODULE ON FIRE %d !!!!\n", cmd->status);

    switch (cmd->id)
    {
        case CSR_CMD_BUILD_ID:
            csr_build_id = cmd->data[0];
            DBG("CSR BuildID: %04x\n", csr_build_id);
            break;

        case CSR_CMD_CHIPVER:
            DBG("CSR chip version: %s\n",
                csr_chipver[cmd->data[0] <= 3 ?
                cmd->data[0] : 4]);
            break;

        case CSR_CMD_CHIPREV:
            detected_chiprevision = cmd->data[0];
            for(i = 0; csr_chiprev[i].value != 00; i++) {
                if(csr_chiprev[i].value == cmd->data[0]) {
                    DBG("CSR chip revision: %s\n",
                        csr_chiprev[i].desc);
                    return;
                }
            }
            DBG("CSR chip revision: %s\n",
                csr_chiprev[i].desc);
            break;

        case CSR_CMD_PS_SIZE:
            DBG("CSR pskey size: key %04x - size %d\n",
                cmd->data[0], cmd->data[1]);
            /* save it for later use */
            pskey_size = cmd->data[1];
            break;
    }
}

/*
 * process a packet received from the module
 */
void process_packet(struct ubcsp_packet *rpacket)
{
    struct csr_msg *msg;
    struct csr_bccmd *cmd;

    /*int i;
    DBG("\n--- received packet: ---\n");
    DBG("channel:  %d\n", rpacket->channel);
    DBG("reliable: %d\n", rpacket->reliable);
    DBG("length:   %d\n", rpacket->length);
    DBG("data:     ");
    for(i = 0; i < rpacket->length; i++)
    {
        DBG("%02x ", rpacket->payload[i]);
    }
    DBG("\n");
    */
    
    if(rpacket->payload[0] == 0xff) {
        msg = (struct csr_msg *)&(rpacket->payload[2]);
        cmd = (struct csr_bccmd *)msg->data;
        /*DBG("==CSR-Message==\n");
        DBG("channel: %lu\n", CSR_GET_CH_ID(msg));*/
        if(CSR_GET_CH_ID(msg) == CSR_CH_ID_BCCMD)
            process_csr_event(cmd);
    }
}

/*
 * build a request packet to read one of the firmware revision fields
 */
void get_firmware_rev_info(struct ubcsp_packet *send_packet, uint16 id)
{
    struct cmd_pkt *pkt;
    struct csr_msg *msg;
    struct csr_bccmd *cmd;

    /* BCSP transport parameters */
    send_packet->channel = 5;
    send_packet->reliable = 1;
    send_packet->length = 1 + 5 * sizeof(uint16) + 6 * sizeof(uint16) +
        CMD_HDR_LEN;

    /* CSR specific header */
    pkt = (struct cmd_pkt *)(send_packet->payload);
    pkt->opcode = hci_put_opcode(0x00, MANUFACTURER_SPEC);
    pkt->len = 1 + 5 * sizeof(uint16) + 6 * sizeof(uint16);

    msg = (struct csr_msg *)pkt->data;
    cmd = (struct csr_bccmd *)msg->data;

    /* general msg header */
    CSR_SET_LAST(msg, 1);
    CSR_SET_FIRST(msg, 1);
    CSR_SET_CH_ID(msg, CSR_CH_ID_BCCMD);

    /* BCCMD type */
    cmd->type = CSR_MSGTYPE_GETREQ;
    cmd->len = 5 + 6;
    cmd->seq = csr_seq++;
    cmd->id = id;
    cmd->status = CSR_STATUS_OK;
    memset(cmd->data, 0x00, 6 * sizeof(uint16));
}

/*
 * build a request packet to ask for the size of a ps key entry
 */
void csr_pssize(struct ubcsp_packet *send_packet, uint16 pskey)
{
    struct cmd_pkt *pkt;
    struct csr_msg *msg;
    struct csr_bccmd *cmd;
    struct csr_bccmd_ps *ps;

    /* BCSP transport parameters */
    send_packet->channel = 5;
    send_packet->reliable = 1;
    send_packet->length = 1 + 5 * sizeof(uint16) + 4 * sizeof(uint16) +
        CMD_HDR_LEN;

    /* CSR specific header */
    pkt = (struct cmd_pkt *)(send_packet->payload);
    pkt->opcode = hci_put_opcode(0x00, MANUFACTURER_SPEC);
    pkt->len = 1 + 5 * sizeof(uint16) + 4 * sizeof(uint16);

    msg = (struct csr_msg *)pkt->data;
    cmd = (struct csr_bccmd *)msg->data;
    ps = (struct csr_bccmd_ps *)cmd->data;

    /* general msg header */
    CSR_SET_LAST(msg, 1);
    CSR_SET_FIRST(msg, 1);
    CSR_SET_CH_ID(msg, CSR_CH_ID_BCCMD);

    /* BCCMD type */
    cmd->type = CSR_MSGTYPE_GETREQ;
    cmd->len = 5 + 4;
    cmd->seq = csr_seq++;
    cmd->id = CSR_CMD_PS_SIZE;
    cmd->status = CSR_STATUS_OK;

    /* actual PS key request */
    ps->ps_key = pskey;
    ps->ps_len = 0;
    ps->unused = 0;
    ps->ps_val[0] = 0;
}

/*
 * construct request packet for reading one of the ps key entries
 */
void csr_getps(struct ubcsp_packet *send_packet, uint16 pskey, int size)
{
    struct cmd_pkt *pkt;
    struct csr_msg *msg;
    struct csr_bccmd *cmd;
    struct csr_bccmd_ps *ps;

    /* BCSP transport parameters */
    send_packet->channel = 5;
    send_packet->reliable = 1;
    send_packet->length = 1 + 5 * sizeof(uint16) + 3 * sizeof(uint16) +
        size * sizeof(uint16) + CMD_HDR_LEN;

    /* CSR specific header */
    pkt = (struct cmd_pkt *)(send_packet->payload);
    pkt->opcode = hci_put_opcode(0x00, MANUFACTURER_SPEC);
    pkt->len = 1 + 5 * sizeof(uint16) + 3 * sizeof(uint16) +
        size * sizeof(uint16);

    msg = (struct csr_msg *)pkt->data;
    cmd = (struct csr_bccmd *)msg->data;
    ps = (struct csr_bccmd_ps *)cmd->data;

    /* general msg header */
    CSR_SET_LAST(msg, 1);
    CSR_SET_FIRST(msg, 1);
    CSR_SET_CH_ID(msg, CSR_CH_ID_BCCMD);

    /* BCCMD type */
    cmd->type = CSR_MSGTYPE_GETREQ;
    cmd->len = 5 + 3 + size;
    cmd->seq = csr_seq++;
    cmd->id = CSR_CMD_PS;
    cmd->status = CSR_STATUS_OK;

    /* actual PS key request */
    ps->ps_key = pskey;
    ps->ps_len = size;
    ps->unused = 0;
    memset(ps->ps_val, 0x00, size * sizeof(uint16));
}

/*
 * set a ps key entry to a new value
 */
void csr_setps(struct ubcsp_packet *send_packet, uint16 pskey, int size,
    uint16 *data)
{
    struct cmd_pkt *pkt;
    struct csr_msg *msg;
    struct csr_bccmd *cmd;
    struct csr_bccmd_ps *ps;

    /* BCSP transport parameters */
    send_packet->channel = 5;
    send_packet->reliable = 1;
    send_packet->length = 1 + 5 * sizeof(uint16) + 3 * sizeof(uint16) +
        size * sizeof(uint16) + CMD_HDR_LEN;

    /* CSR specific header */
    pkt = (struct cmd_pkt *)(send_packet->payload);
    pkt->opcode = hci_put_opcode(0x00, MANUFACTURER_SPEC);
    pkt->len = 1 + 5 * sizeof(uint16) + 3 * sizeof(uint16) +
        size * sizeof(uint16);

    msg = (struct csr_msg *)pkt->data;
    cmd = (struct csr_bccmd *)msg->data;
    ps = (struct csr_bccmd_ps *)cmd->data;

    /* general msg header */
    CSR_SET_LAST(msg, 1);
    CSR_SET_FIRST(msg, 1);
    CSR_SET_CH_ID(msg, CSR_CH_ID_BCCMD);

    /* BCCMD type */
    cmd->type = CSR_MSGTYPE_SETREQ;
    cmd->len = 5 + 3 + size;
    cmd->seq = csr_seq++;
    cmd->id = CSR_CMD_PS;
    cmd->status = CSR_STATUS_OK;

    /* actual PS key request */
    ps->ps_key = pskey;
    ps->ps_len = size;
    ps->unused = 0;
    memcpy(ps->ps_val, data, size * sizeof(uint16));
}

/*
 * csr_command (warm reset, warm halt, disable_tx, enable_tx) the CSR module
 */
void csr_command(struct ubcsp_packet *send_packet, uint16 varid)
{
    struct cmd_pkt *pkt;
    struct csr_msg *msg;
    struct csr_bccmd *cmd;

        /* BCSP transport parameters */
    send_packet->channel = 5;
    send_packet->reliable = 1;
    send_packet->length = 1 + 5 * sizeof(uint16) + 4 * sizeof(uint16) +
        CMD_HDR_LEN;

    /* CSR specific header */
    pkt = (struct cmd_pkt *)(send_packet->payload);
    pkt->opcode = hci_put_opcode(0x00, MANUFACTURER_SPEC);
    pkt->len = 1 + 5 * sizeof(uint16) + 4 * sizeof(uint16);

    msg = (struct csr_msg *)pkt->data;
    cmd = (struct csr_bccmd *)msg->data;

    /* general msg header */
    CSR_SET_LAST(msg, 1);
    CSR_SET_FIRST(msg, 1);
    CSR_SET_CH_ID(msg, CSR_CH_ID_BCCMD);

    /* BCCMD type */
    cmd->type = CSR_MSGTYPE_SETREQ;
    cmd->len = 5 + 4;
    cmd->seq = csr_seq++;
    cmd->id = varid;
    cmd->status = CSR_STATUS_OK;
    memset(cmd->data, 0x00, 4 * sizeof(uint16));
}

/******************************************************************************/


static int get_bdaddr_from_file(char* afilename, uint8* bdaddr)
{
    int n;
    const uint8 tomtom_bdid1[3] = {0x00, 0x13, 0x6c};
    const uint8 tomtom_bdid2[3] = {0x00, 0x21, 0x3e};
    unsigned char buffer[6];

    FILE*f=fopen(afilename,"rb");
    if (!f)
    {
        fprintf(stderr, "Warning: could not open file with MAC address %s\n",afilename);
        return 0;  
    }
    n = fread(buffer,1,6,f);
    fclose(f);

    if (n != 6)
    {
        fprintf(stderr, "Warning: MAC address was only %d bytes\n",n);
        goto FAIL_MAC_ADDRESS;
    }
    if (buffer[0] == 0xff)
    {
        fprintf(stderr, "Warning: MAC address seems to be 0xff\n");
        goto FAIL_MAC_ADDRESS;
    }
    if ((memcmp(buffer,tomtom_bdid1,3) != 0) && (memcmp(buffer,tomtom_bdid2,3) != 0))
        {
        fprintf(stderr, "Warning: MAC address [0..2] incorrect 0x%02x 0x%02x 0x%02x\n",buffer[0],buffer[1],buffer[2]);
        if ((buffer[0] == tomtom_bdid1[1]) && (buffer[1] == 0x00)) {
            fprintf(stderr, "Suggestion: swap 16-bit wise, buf[0] and buf[1], buf[2] and buf[3], buf[4] and buf[5]\n");
        }
        if ((buffer[5] == tomtom_bdid1[0]) && (buffer[4] == tomtom_bdid1[1]) && (buffer[3] == tomtom_bdid1[2])) {
            fprintf(stderr, "Suggestion: write the bytes from 0 to 5 instead of 5 to 0\n");
        }
        if ((buffer[0] == tomtom_bdid2[1]) && (buffer[1] == 0x00)) {
            fprintf(stderr, "Suggestion: swap 16-bit wise, buf[0] and buf[1], buf[2] and buf[3], buf[4] and buf[5]\n");
        }
        if ((buffer[5] == tomtom_bdid2[0]) && (buffer[4] == tomtom_bdid2[1]) && (buffer[3] == tomtom_bdid2[2])) {
            fprintf(stderr, "Suggestion: write the bytes from 0 to 5 instead of 5 to 0\n");
        }
        goto FAIL_MAC_ADDRESS;
    }
    memcpy(bdaddr,buffer,6);
    return 6;
FAIL_MAC_ADDRESS:
    for (n=0; n<6; n++)
    {
        DBG("0x%02x ",buffer[n]);
    }
    DBG("\n");
    return 0;
}

static int get_bdaddr_from_commandline(uint8* bdaddr)
{
    int n;
    const uint8 tomtom_bdid1[3] = {0x00, 0x13, 0x6c};
    const uint8 tomtom_bdid2[3] = {0x00, 0x21, 0x3e};
    unsigned char buffer[6];

    memcpy(buffer,bdAddress, 6);
    DBG("MAC address from commandline [0x%02x:0x%02x:0x%02x:0x%02x:0x%02x:0x%02x\n",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5]);

    if (!ignore_unknown_bd_address)
    {
        if (buffer[0] == 0xff)
        {
            fprintf(stderr, "Warning: MAC address seems to be 0xff\n");
            fprintf(stderr, "FAILED to read valid MAC addr succesfully from commandline\n");
            goto FAIL_MAC_ADDRESS;
        }
        if ((memcmp(buffer,tomtom_bdid1,3) != 0) && (memcmp(buffer,tomtom_bdid2,3) != 0))
        {
            fprintf(stderr, "Warning: MAC address [0..2] incorrect 0x%02x 0x%02x 0x%02x\n",buffer[0],buffer[1],buffer[2]);
            if ((buffer[0] == tomtom_bdid1[1]) && (buffer[1] == 0x00)) {
                    fprintf(stderr, "Suggestion: swap 16-bit wise, buf[0] and buf[1], buf[2] and buf[3], buf[4] and buf[5]\n");
            }
            if ((buffer[5] == tomtom_bdid1[0]) && (buffer[4] == tomtom_bdid1[1]) && (buffer[3] == tomtom_bdid1[2])) {
                    fprintf(stderr, "Suggestion: write the bytes from 0 to 5 instead of 5 to 0\n");
            }
            if ((buffer[0] == tomtom_bdid2[1]) && (buffer[1] == 0x00)) {
                    fprintf(stderr, "Suggestion: swap 16-bit wise, buf[0] and buf[1], buf[2] and buf[3], buf[4] and buf[5]\n");
            }
            if ((buffer[5] == tomtom_bdid2[0]) && (buffer[4] == tomtom_bdid2[1]) && (buffer[3] == tomtom_bdid2[2])) {
                    fprintf(stderr, "Suggestion: write the bytes from 0 to 5 instead of 5 to 0\n");
            }
            fprintf(stderr, "FAILED to read valid MAC addr succesfully from commandline.\n");
            goto FAIL_MAC_ADDRESS;
        }
    }
    memcpy(bdaddr,buffer,6);
    return 6;
FAIL_MAC_ADDRESS:
    for (n=0; n<6; n++)
    {
        DBG("0x%02x ",buffer[n]);
    }
    DBG("\n");
    return 0;
}

/*
 * sets the BDADDR - uses the TomTom OUI 00-13-6c
 */
void set_bdaddr(struct ubcsp_packet *send_packet)
{
    uint8 bdaddr[] = {0x00, 0x13, 0x6c, 0x00, 0x00, 0x00};
    uint16 data[4];

    int fd;
    int bdaddr_oke = 0;

    if (btAddrSpecifiedOnCommandLine)
    {
        bdaddr_oke = get_bdaddr_from_commandline(bdaddr);
    }
    else
    {
        /* Read mac address from /mnt/flash/sysfile/mac */
        bdaddr_oke = get_bdaddr_from_file("/mnt/flash/sysfile/mac", bdaddr);
    }
    if (!bdaddr_oke)
    {
        if(!get_bdaddr_from_file("/mnt/flash/mactemp", bdaddr)) {
            fprintf(stderr, "Could not open temporary mac file, creating one instead\n");

            fd = open("/dev/urandom", O_RDONLY);
            read(fd, &bdaddr[3], 3);
            close(fd);
            bdaddr[0] = 0x00;
            bdaddr[1] = 0x13;
            bdaddr[2] = 0x6c;

            FILE *f = fopen("/mnt/flash/mactemp", "wb");
            if(f) {
                fwrite(bdaddr, 1, 6, f);
                fclose(f);
            }
        } else {
            fprintf(stderr, "Warning: Got mac address from temp mac file "
                "(some random number)\n");
        }
    }

    fprintf(stderr,"Final BDADDR=%02X:%02X:%02X:%02X:%02X:%02X\n",
        bdaddr[0], bdaddr[1], bdaddr[2],
        bdaddr[3], bdaddr[4], bdaddr[5]);

    data[0] = bdaddr[3];
    data[1] = bdaddr[4] << 8 | bdaddr[5];
    data[2] = bdaddr[2];
    data[3] = bdaddr[0] << 8 | bdaddr[1];
    DBG("Setting CSR BDADDR\n");
    csr_setps(send_packet, CSR_PS_BDADDR, 4, data);
}

/*
 * basic state machine
 * we start with state 10 and after every reply we received we continue with
 * the next one...
 * punchcard like state machine...
 */
void send_next_packet(struct ubcsp_packet *send_packet)
{
    uint16 data[76];
    int i, num_ents = 0;
    char *p = NULL;

    switch (state)
    {
        /**************************************************************/
        case 10:
            /* read chip family */
            DBG("reading chip family\n");
            get_firmware_rev_info(send_packet, CSR_CMD_CHIPVER);
            state = 11;
            break;
        case 11:
            /* read firmware build id */
            DBG("reading firmware build id\n");
            get_firmware_rev_info(send_packet, CSR_CMD_BUILD_ID);
            state = 12;
            break;
        case 12:
            /* read chip revision */
            DBG("reading chip revision\n");
            get_firmware_rev_info(send_packet, CSR_CMD_CHIPREV);
            state = 13;
            break;
        case 13:
            // making sure sco uses hci in stead of pcm 
            memset(data, 0x00, sizeof(data));
            data[0]  = 0x0000;
            csr_setps(send_packet, CSR_PS_HOSTIO_MAP_SCO_PCM, 1, data);
            if (no_deep_sleep_during_audio_handling) state = 14;
            else state = 20;
            break;
        case 14:
            // this state is used for 65x release(s) only
            // making sure cpu clock will not in to deep a power down mode during audio handling 
            memset(data, 0x00, sizeof(data));
            data[0]  = 0x0000;
            csr_setps(send_packet, 0x024D, 1, data);
            DBG("min_cpu_clock %d\n",data[0]);
            state = 20;
            break;
        /**************************************************************/
        case 20:
            /* set external crystal frequency */
            memset(data, 0x00, sizeof(data));
            data[0] = (crystal_freq / 1000); /* ~16 or solid 26 MHz */
            csr_setps(send_packet, CSR_PS_ANA_FREQ, 1, data);
            state = 21;
            break;
        case 21:
            /* set bluetooth class of device */
            memset(data, 0x00, sizeof(data));
            data[0] = 0;
            csr_setps(send_packet, CSR_PS_CLASSOFDEVICE, 1, data);
            state = 22;
            break;
        case 22:
            /* set bluetooth module country code */
            memset(data, 0x00, sizeof(data));
            data[0] = 0x00; /* North America & Europe */
            csr_setps(send_packet, CSR_PS_COUNTRYCODE, 1, data);
            state = 23;
            break;
        case 23:
            /* configure CSR host interface protocol */
            switch (mode)
            {
              case BCCMDMODE_H4:         
                p = "H4";         data[0] = 0x03; 
                break;
              case BCCMDMODE_UBCSP: 
                p = "UBCSP";    data[0] = 0x01;
                break;
#ifdef SUPPORT_USB
              case BCCMDMODE_USB:     
                p = "USB";         data[0] = 0x02;
                break;
#endif
              default:
                p = "";
                break;
            }

            DBG("configuring host interface protocol to %s\n", p);
            csr_setps(send_packet, CSR_PS_HOST_INTERFACE, 1, data);
            state = 24;
            break;
        case 24:
            /* set default transmit power in dBm */
            memset(data, 0x00, sizeof(data));
            data[0] = 20; /* 20 dBm */
            csr_setps(send_packet, CSR_PS_LC_DEFAULT_TX_POWER,
                1, data);
#ifdef SUPPORT_USB
            if (mode == BCCMDMODE_USB)
            {
              state = 40; /* skip baudrate stuff */
            }
            else
#endif
            {
              state = 25;
            }
            break;
        case 25:
            /* set baud rate */
            memset(data, 0x00, sizeof(data));
            DBG("setting UART to real_baudrate %d CSR_PS_UART_BAUD_RATE= %d)\n",
                   real_baudrate, ps_uart_baudrate_value);
            data[0]= ps_uart_baudrate_value;
            csr_setps(send_packet, CSR_PS_UART_BAUD_RATE, 1, data);
            state = 26;
            break;
        case 26:
            /* disable RTS/CTS flow control */
            memset(data, 0x00, sizeof(data));
            data[0] = 0; /* disable RTS/CTS */
            csr_setps(send_packet, CSR_PS_UART_CONFIG_FLOW_CTRL_EN,
                1, data);
            state = 27;
            break;

        /******************************************************/    
#ifdef SUPPORT_USB
        case 40:
            /* USB productid */
            memset(data, 0x00, sizeof(data));
            data[0] = 0x4d4a;
            csr_setps(send_packet, CSR_PS_USB_PRODUCTID, 1, data);
            state = 41;
            break;

        case 41:
            /* USB vendorid */
            memset(data, 0x00, sizeof(data));
            data[0] = 0x1390; /* TomTom USB vendorID */
            csr_setps(send_packet, CSR_PS_USB_VENDORID, 1, data);
            state = 27;
            break;

#endif
        case 27:
            /* setup external buffer capacitor on AIO(2) */
            // DBG("enabling external filter capacitor\n");
            memset(data, 0x00, sizeof(data));
            data[0] = 1; /* read datasheet to understand... */
            csr_setps(send_packet, CSR_PS_AMUX_B, 1, data);
            state = 28;
            break;
        case 28:
            /* setup external PA control to 'non existing' */
            // DBG("disabling external PA control\n");
            memset(data, 0x00, sizeof(data));
            data[0] = 0;
            csr_setps(send_packet, CSR_PS_TXRX_PIO_CONTROL,
                1, data);
//            state = 80;
            state = 29;
            break;
        case 29:
            /* setup the power table, see AN051 */
            if (!use_enhanced_power_table)
            {
                memset(data, 0x00, sizeof(data));

                /* fill btcal_flash with 0xffff in case file can't be read */
                memset(&btcal_flash, 0xff, sizeof(btcal_flash));

                DBG("generating CSR_PS_LC_POWER_TABLE\n");

                btcal_flash.power_table[0].u.external_pa = 0;
                btcal_flash.power_table[0].u.internal_pa = 14;
                btcal_flash.power_table[0].u.tx_dbm      = (uint8)-20;
                btcal_flash.power_table[0].u.reserved    = 0;

                btcal_flash.power_table[1].u.external_pa = 0;
                btcal_flash.power_table[1].u.internal_pa = 19;
                btcal_flash.power_table[1].u.tx_dbm         = (uint8)-16;
                btcal_flash.power_table[1].u.reserved    = 0;

                btcal_flash.power_table[2].u.external_pa = 0;
                btcal_flash.power_table[2].u.internal_pa = 24;
                btcal_flash.power_table[2].u.tx_dbm      = (uint8)-12;
                btcal_flash.power_table[2].u.reserved    = 0;

                btcal_flash.power_table[3].u.external_pa = 0;
                btcal_flash.power_table[3].u.internal_pa = 31;
                btcal_flash.power_table[3].u.tx_dbm      = (uint8)-8;
                btcal_flash.power_table[3].u.reserved    = 0;

                btcal_flash.power_table[4].u.external_pa = 0;
                btcal_flash.power_table[4].u.internal_pa = 39;
                btcal_flash.power_table[4].u.tx_dbm      = (uint8)-4;
                btcal_flash.power_table[4].u.reserved    = 0;

                btcal_flash.power_table[5].u.external_pa = 0;
                btcal_flash.power_table[5].u.internal_pa = 47;
                btcal_flash.power_table[5].u.tx_dbm      = (uint8)-0;
                btcal_flash.power_table[5].u.reserved    = 0;

                btcal_flash.power_table[6].u.external_pa = 0;
                btcal_flash.power_table[6].u.internal_pa = 54;
                  btcal_flash.power_table[6].u.tx_dbm      = (uint8)3;
                btcal_flash.power_table[6].u.reserved    = 0;

                btcal_flash.power_table[7].u.external_pa = 0;
                btcal_flash.power_table[7].u.internal_pa = 63;
                btcal_flash.power_table[7].u.tx_dbm      = (uint8)6;
                btcal_flash.power_table[7].u.reserved    = 0;

                btcal_flash.power_table[8].raw = 0x00000000;

                num_ents = 0;
                for (i=0; i<9; i++) {
                    data[i*2+0] = (btcal_flash.power_table[i].u.internal_pa << 8) |
                                  btcal_flash.power_table[i].u.external_pa;
                    data[i*2+1] = ( ((uint8)btcal_flash.power_table[i].u.tx_dbm) << 8)|
                                  btcal_flash.power_table[i].u.reserved;
                    if (btcal_flash.power_table[i].raw != 0x00000000)
                        num_ents++;
                    else 
                        break; // last entry
                }
                if (btcal_sanity_check() == 0) {
#ifdef SEND_POWERTABLE
                    DBG("Sending powertable, %d entries\n", num_ents);
                    csr_setps(send_packet, CSR_PS_LC_POWER_TABLE, num_ents * 2, &data[0]); 
#else
                    DBG("Skipping powertable\n");
#endif
                } else {
                    DBG("NOT sending BT powertable: flash powertable sanity check failed.\n");
                }
            }
            else   // use_enhanced_power_table
            {
                DBG("About to send enhanced power table. (size %d)\nWarning: reduced Bluetooth range.\n", sizeof(psset_0031));
                csr_setps(send_packet, CSR_PS_LC_ENHANCED_POWER_TABLE, sizeof(psset_0031)/2, &psset_0031[0]);
            }

            state = 30;
            break;
        /**************************************************************/
        case 30:
            /* get storage size of BDADDR ps key */
                        //      DBG("##### 1 Geting the size of the BDADDRE ");
            csr_pssize(send_packet, CSR_PS_BDADDR);
            state = 31;
            break;
        case 31:
            /* read BDADDR */
                        //      DBG("##### 1 Geting the BDADDRE size of key %d", pskey_size);
            csr_getps(send_packet, CSR_PS_BDADDR, pskey_size);
            state = 32;
            break;
        case 32:
            /* set BDADDR to TomTom OUI and serial number */
            set_bdaddr(send_packet);
            state = 33;
            break;
        case 33:
            if (use_frequency_trim_value)
            {
                /* read ana_ftrim from /mnt/flash/sysfile/btcal */
                /* this is a file mapped to flash offset 0x0000014C */
                /* format of this offset data is:     
                    2 bytes Crystal trim 
                    4 bytes Power table 1 (deprecated)
                    4 bytes Power table 2 (deprecated)
                    406 bytes up to power table 60
                */
                if (ext_clock) 
                      {
                    DBG("Setting ANA_FTRIM to 0, external clock\n");
                    btcal_flash.crystal_trim = 0;
                } 
                      else 
                      {
                        if (ana_trim >= 0)
                        {
                              DBG("Use ANA_TRIM specified by command line : %d\n",ana_trim);
                              btcal_flash.crystal_trim = ana_trim;
                        }
                        else
                        {
                              int fd = open("/mnt/flash/sysfile/btcal", O_RDONLY);
                      if (fd == -1) {
                          DBG("Err opening btcal file\n");
                          btcal_flash.crystal_trim = 0xffff;
                      } else {
                          /* 2 bytes ANA_FTRIM, +2 deprecated pt entries */
                          const int pt_flash_len = 2;
                          if (read(fd, &btcal_flash, pt_flash_len) != pt_flash_len) {
                              DBG("Err reading btcal file %d bytes\n", pt_flash_len);
                              btcal_flash.crystal_trim = 0xffff;
                          } else {
                              // Only read ANA_FTRIM
                              // rest (8 bytes) is deprecated powertable data
                              DBG("Read ANA_FTRIM %04x\n", btcal_flash.crystal_trim);
                              btcal_flash.crystal_trim &= 0x00ff;
                              DBG("Truncated to ANA_FTRIM %04x\n", btcal_flash.crystal_trim);
                          }
                      }
                    }
                }
                /* set PS_ANA_FTRIM, 0-63, 1 bit = ~110 femtoFarad */
                /* was read from flash in state 21 */
                /* was read from flash in state 21 */
                data[0] = btcal_flash.crystal_trim;
                if (data[0] > 0x3f) {
                    DBG("Invalid btcal, centering ANA_FTRIM\n");
                    DBG("WARNING: bad bluetooth performance\n");
                    data[0] = 31; /* ~center of 0-63 */
                }
                csr_setps(send_packet, CSR_PS_ANA_FTRIM, 1, data);
                fprintf(stderr,"setting ANA_FTRIM %d * ~110 femtoF\n", data[0]);
            }
            else
            {
                DBG("setting ANA_FTRIM not necessary.\n");
            }
            state = 34;
            break;

        /**************************************************************/
        case 34:
            /* set bluetooth features */
             /* original configuration: 0xff 0xff 0x8f 0xf8 0x18 0x18 0x00 0x80
              * modified configuration: 0xff 0xff 0x8f 0x78 0x18 0x18 0x00 0x80
             * this is chip dependent data, so needs to be derived from original feature configuration,
             * original feature configuration can be obtained via HCI interface using following sequence:
             * 1) disable this case statement (should go to the next state immediatelly)
             * 2) recompile and reinstalling csrinit on the GO
             * 3) running rc.suspend and then rc.resume from /etc to update csr chip configuration
             * 4) run "hciconfig hci0 features" which will print original hex feature configuration string
             * 5) modify the string to disable EHV3 support, bit 24 set to 0; same for EV5, EV4 ? bits 38,39? (eSCO)
             * 6) update the data[] assignments below and recompile/reinstall csrinit */
            // DBG("setting bluetooth features of device\n");0
            memset(data, 0x00, sizeof(data));
            data[0] = 0xffff;
            data[1] = 0x788f;
            data[2] = 0x1818;
            data[3] = 0x8000;
            csr_setps(send_packet, CSR_PS_FEATURES, 4, data);
            state = 35;
            break;

        case 35:
            /* increase SCO buffer */
            memset(data, 0x00, sizeof(data));
            data[0] = 0x000a;
            data[1] = 0x00a0;
            csr_setps(send_packet, CSR_PS_HOSTIO_SCO_HCI_THRESHOLDS, 2,
                data);
            state = 36;
            break;
        case 36:
            /* max number of open SCO channels is 2 */
            memset(data, 0x00, sizeof(data));
            data[0] = 0x0002;
            csr_setps(send_packet, CSR_PS_MAX_SCOS, 1, data);

            if (detected_chiprevision == CHIPREVISION_BLUECORE3_ROM)
            {
                if ((csr_build_id == 1298) || (csr_build_id == 1593))
                  state = 55; /* patch BC3ROM */
                else
                {
                    state = 97;   /* reboot sequence */
                }
            }
            else if (detected_chiprevision == CHIPREVISION_BLUECORE4_ROM)
            {
                switch (csr_build_id)
                {
                  case 1958:
                    state = 60;   /* patches for BC4-ROM build 1958 */
                    break;
                  case 3164:
                    state = 72;   /* patches for BC4-ROM build 3164 */
                    break;
                  case 4839:
                    DBG("warning: no patches\n");
                    state = 97;   /* no patches for BC4-ROM build 4839 yet, so reboot sequence */
                    break;
                  default:
                    /* detected new CSR build id, so we need new patches !! */
                    DBG("warning: detected unknown CSR BC4-ROM build id; Do we need new patches?\n");   /* if not, please make it explicit here. */
                    state = 97;   /* reboot sequence */
                }
            }
            else
            {
                /* just reboot */
                state = 97;
            }
            break;
        case 55:
            /* patch BC3ROM, part 1 */
            DBG("Patching BC3ROM firmware (patch 22, build id %d)\n", csr_build_id);
            
            memcpy(&data[0], patch_22, sizeof(patch_22));
            if (csr_build_id == 1298) data[36] = 0xec80;
            if (csr_build_id == 1593) data[36] = 0xeda7;
            csr_setps(send_packet, CSR_PS_PATCH_22, 36, data);

            state = 97; // just reboot
            break;

        /**************************************************************/
        // patch cores when needed
        case 60:
            // patch_spare5, PSKEY_PATCH34 (0x00b8, 184)
            // DBG("send patch 34\n");
            csr_setps(send_packet, csr_b1958_patch_34_pskey, sizeof_patch(csr_b1958_patch_34_data), csr_b1958_patch_34_data);
            state = 61;
            break;

        case 61:
            // patch_spare4, PSKEY_PATCH33 (0x00b7, 183)
            // DBG("send patch 33\n");
            csr_setps(send_packet, csr_b1958_patch_33_pskey, sizeof_patch(csr_b1958_patch_33_data), csr_b1958_patch_33_data);
            state = 62;
            break;

        case 62:
            // patch_spare6, PSKEY_PATCH35 (0x00b9, 185)
            // DBG("send patch 35\n");
            csr_setps(send_packet, csr_b1958_patch_35_pskey, sizeof_patch(csr_b1958_patch_35_data), csr_b1958_patch_35_data);
            state = 63;
            break;

        case 63:
            // patch_bc_boot, PSKEY_PATCH1 (0x0097, 151)
            // DBG("send patch 1\n");
            csr_setps(send_packet, csr_b1958_patch_1_pskey, sizeof_patch(csr_b1958_patch_1_data), csr_b1958_patch_1_data);
            state = 64;
            break;

        case 64:
            // patch_spare7, PSKEY_PATCH36 (0x00ba, 186)
            // DBG("send patch 36\n");
            csr_setps(send_packet, csr_b1958_patch_36_pskey, sizeof_patch(csr_b1958_patch_36_data), csr_b1958_patch_36_data);
            state = 65;
            break;

        case 65:
            // patch_spare3, PSKEY_PATCH32 (0x00b6, 182)
            // DBG("send patch 32\n");
            csr_setps(send_packet, csr_b1958_patch_32_pskey, sizeof_patch(csr_b1958_patch_32_data), csr_b1958_patch_32_data);
            state = 67;
            break;

            // patch_38, PSKEY_PATCH38 (0x00bc, 188)
            // state 66 ?
            // DBG("send patch 38\n");
            csr_setps(send_packet, csr_b1958_patch_38_pskey, sizeof_patch(csr_b1958_patch_38_data), csr_b1958_patch_38_data);

        case 67:
            // patch_spare2, PSKEY_PATCH31 (0x00b5, 181)
            // DBG("send patch 31\n");
            csr_setps(send_packet, csr_b1958_patch_31_pskey, sizeof_patch(csr_b1958_patch_31_data), csr_b1958_patch_31_data);
            state = 68;
            break;

        case 68:
            // patch_37, PSKEY_PATCH37 (0x00bb, 187)
            // DBG("send patch 37\n");
            csr_setps(send_packet, csr_b1958_patch_37_pskey, sizeof_patch(csr_b1958_patch_37_data), csr_b1958_patch_37_data);
            state = 69;
            break;

        case 69:
            // patch_radiotest_tx_start, PSKEY_PATCH17 (0x00a7, 167)
            // DBG("send patch 17\n");
            csr_setps(send_packet, csr_b1958_patch_17_pskey, sizeof_patch(csr_b1958_patch_17_data), csr_b1958_patch_17_data);
            state = 70;
            break;

        case 70:
            // patch_lc_rx_hw_set, PSKEY_PATCH25 (0x00af, 175)
            // DBG("send patch 25\n");
            csr_setps(send_packet, csr_b1958_patch_25_pskey, sizeof_patch(csr_b1958_patch_25_data), csr_b1958_patch_25_data);
            state = 71;
            break;

        case 71:
            // patch_spare1, PSKEY_PATCH30 (0x00b4, 180)
            // DBG("send patch 30\n");
            csr_setps(send_packet, csr_b1958_patch_30_pskey, sizeof_patch(csr_b1958_patch_30_data), csr_b1958_patch_30_data);
            // state = 82;
            state = 97;
            break;

        case 72:
            // DBG("send patch 56\n");
            csr_setps(send_packet, csr_b3164_patch_56_pskey, sizeof_patch(csr_b3164_patch_56_data), csr_b3164_patch_56_data);
            state = 73;
            break;

        case 73:
            // DBG("send patch 28\n");
            csr_setps(send_packet, csr_b3164_patch_28_pskey, sizeof_patch(csr_b3164_patch_28_data), csr_b3164_patch_28_data);
            state = 74;
            break;

        case 74:
            // DBG("send patch 57\n");
            csr_setps(send_packet, csr_b3164_patch_57_pskey, sizeof_patch(csr_b3164_patch_57_data), csr_b3164_patch_57_data);
            state = 75;
            break;

        case 75:
            // DBG("send patch 22\n");
            csr_setps(send_packet, csr_b3164_patch_22_pskey, sizeof_patch(csr_b3164_patch_22_data), csr_b3164_patch_22_data);
            state = 76;
            break;

        case 76:
            // DBG("send patch 53\n");
            csr_setps(send_packet, csr_b3164_patch_53_pskey, sizeof_patch(csr_b3164_patch_53_data), csr_b3164_patch_53_data);
            state = 77;
            break;

        case 77:
            // DBG("send patch 54\n");
            csr_setps(send_packet, csr_b3164_patch_54_pskey, sizeof_patch(csr_b3164_patch_54_data), csr_b3164_patch_54_data);
            state = 78;
            break;

        case 78:
            // DBG("send patch 52\n");
            csr_setps(send_packet, csr_b3164_patch_52_pskey, sizeof_patch(csr_b3164_patch_52_data), csr_b3164_patch_52_data);
            state = 79;
            break;

        case 79:
            // DBG("send patch 55\n");
            csr_setps(send_packet, csr_b3164_patch_55_pskey, sizeof_patch(csr_b3164_patch_55_data), csr_b3164_patch_55_data);
            state = 97;   /* reboot sequence */
            break;

#ifdef DO_NOT_USE
    case 80:
      /* get storage size of BDADDR ps key */
      DBG("##### Geting the size of the BDADDRE ");
      csr_pssize(send_packet, CSR_PS_LC_ENHANCED_POWER_TABLE);
      state = 81;
      break;
    case 81:
      /* read BDADDR */
      DBG("##### Geting the BDADDRE size of key %d", pskey_size);
      csr_getps(send_packet, CSR_PS_LC_ENHANCED_POWER_TABLE, pskey_size);
      state = 29;
      break;

    case 82:
      /* get storage size of BDADDR ps key */
      DBG("##### Geting the size of the BDADDRE ");
      csr_pssize(send_packet, CSR_PS_LC_ENHANCED_POWER_TABLE);
      state = 83;
      break;
    case 83:
      /* read BDADDR */
      DBG("##### Geting the BDADDRE size of key %d", pskey_size);
      csr_getps(send_packet, CSR_PS_LC_ENHANCED_POWER_TABLE, pskey_size);
      state = 97;
      break;

#endif

    /* Note : TomTom uses default settings for power saving mode DEEP SLEEP 
       - PSKEY_DEEP_SLEEP_STATE    0x0229 = 1 (DEEP_SLEEP_ALWAYS) 
       - PSKEY_UART_SLEEP_TIMEOUT  0x0222 = 1000 (1 sec.) 
           with these settings the deep sleep mode is entered whenever possible.
    */
     
    case 97:
        /* enable PS key protection */
        if (!skip_pskey_protection)
        {
            memset(data, 0x00, sizeof(data));
            data[0] = 1;
            csr_setps(send_packet, CSR_PS_BCCMD_SECURITY_ACTIVE, 1,
                data);
        }
            state = 98;
            break;
    case 98:
            /* warm reboot CSR chip */
            DBG("warm reboot\n");
            csr_command(send_packet, CSR_WARM_RESET);
            state = 99;
            break;
    case 99:
      return;
        
    // special commands section
    case 110:
      DBG("send CSR_WARM_RESET\n");             
      csr_command(send_packet, CSR_WARM_RESET);
      state = 99;
      break; 
    case 111:
      DBG("send CSR_WARM_HALT\n"); 
      csr_command(send_packet, CSR_WARM_HALT);
      state = 99;
      break;
    case 112:
      DBG("send CSR_DISABLE_TX\n"); 
      csr_command(send_packet, CSR_DISABLE_TX);
      state = 99;
      break; 
    case 113:
      DBG("send CSR_ENABLE_TX\n"); 
      csr_command(send_packet, CSR_ENABLE_TX);
      state = 99;
      break;        
    }

    {
        /*
        int i;
        DBG("\n--- sending packet: ---\n");
        DBG("channel:  %d\n", send_packet->channel);
        DBG("reliable: %d\n", send_packet->reliable);
        DBG("length:   %d\n", send_packet->length);
        DBG("data:     ");
        for(i = 0; i < send_packet->length; i++)
        {
            DBG("%02x ", send_packet->payload[i]);
        }
        DBG("\n");*/
    }
}

#ifdef SUPPORT_USB
void do_pretty_amazing_usb_magic()
{
    struct ubcsp_packet send_packet;
    uint8 send_buffer[512];
    struct ubcsp_packet receive_packet;
    uint8 receive_buffer[512];

    memset(&send_packet, 0, sizeof send_packet);
    memset(&receive_packet, 0, sizeof receive_packet);

    /* setup the receive packet payload */
    send_packet.length = 512;
    send_packet.payload = send_buffer;

    /* setup the packets payload pointer */
    receive_packet.length = 512;
    receive_packet.payload = receive_buffer;

    // TODO: move PS statemachine stuff to other file
    state = 10; // 33 ;

    /* pick up a waiting HCI status packet, ignore */
    usb_receive_packet(&receive_packet);
    
    while (state != 99) {
        /* prepare next packet */
        send_next_packet(&send_packet);
        /* TODO: send USB HCI commands */
        send_usb_packet(&send_packet.payload[0], send_packet.length); /* offset 8 should be the 'desc' field of csr_msg */
    
        usb_receive_packet(&receive_packet);
        process_packet(&receive_packet);
    }
    
}
#endif

int detect_nop(struct ubcsp_packet *rpacket)
{
    static char nop_frame[6] = {0x0f, 0x04, 0x00, 0x01, 0x00, 0x00};
    return (memcmp(rpacket->payload, nop_frame, 6) == 0);
}


/*
 * do one complete run through all states
 */
int do_pretty_amazing_magic()
{
    uint8 activity;
    int delay = 0;
    int timeout = 0;

    struct ubcsp_packet send_packet;
    uint8 send_buffer[512];
    struct ubcsp_packet receive_packet;
    uint8 receive_buffer[512];

    memset(&send_packet, 0, sizeof send_packet);
    memset(&receive_packet, 0, sizeof receive_packet);

    /* setup the receive packet payload */
    send_packet.length = 512;
    send_packet.payload = send_buffer;

    /* setup the packets payload pointer */
    receive_packet.length = 512;
    receive_packet.payload = receive_buffer;

  if (warm_reset)
    state = 110;
    else if (warm_halt)
     state = 111;
  else if (disable_tx)
    state = 112;
  else if (enable_tx)
    state = 113;  
  else
       state = 10;


    /* ask ubcsp to receive a packet -- initiates the link establishment */
    ubcsp_receive_packet(&receive_packet);

    /* start our punchcard... */
    timeout = 0;
    int ready = 0, pending_send = 0;
    while(1) {
        delay = ubcsp_poll(&activity);
        if (!ready && (activity & UBCSP_PACKET_SENT))
            pending_send = 1;
        if(activity & UBCSP_PACKET_RECEIVED) {
            /* process the newly arrived packet */
            process_packet(&receive_packet);
            if (detect_nop(&receive_packet)) {
                ready = 1;
                if (pending_send)
                    activity |= UBCSP_PACKET_SENT;
            }
            /* reschedule the receive buffer */
            receive_packet.length = 512;
            ubcsp_receive_packet(&receive_packet);

            timeout = 0;
        }
        if(ready && (activity & UBCSP_PACKET_SENT)) {
            /* advance punchcard one step... */
            send_next_packet(&send_packet);
            ubcsp_send_packet(&send_packet);
            timeout = 0;
        }

        if(delay) {
            /* sleep some 100ms */
            usleep(10000);
            timeout++;
            if((timeout >= 1) && (state == 99)) {
                fprintf(stderr, "configuration complete\n");
                return 0;
            }
            if(timeout >= 500) {
                fprintf(stderr, "timed out waiting for a packet\n");
                return -1;
            }
        }
    }
}

//divide round (nom/den +0.5)
static inline int divrnd(int nom, int den)
{
   return (nom + den / 2) / den;
}

// CSR_PS_UART_BAUD_RATE is independent from Xtal frequency 
// and according to the datasheet it is calculated as follows
// pskey_uart_baudrate = rate * 0.004096
// 128/31250 = 0.004096
static inline uint16 calc_ps_uart_baudrate_value(int rate)
{
   return divrnd(rate * 128, 31250);	
}


/******************************************************************************/

#define GPIO_DRIVER_MAGIC                'U'
#ifndef Nashville_kernel_2_6_23_arm9
#define IOR_HWSTATUS          _IOR(GPIO_DRIVER_MAGIC, 0, HARDWARE_STATUS)
#define IOR_DISK_ACCESS       _IOR(GPIO_DRIVER_MAGIC, 7, unsigned int)
#endif
#define IOR_BT_MODE           _IOR(GPIO_DRIVER_MAGIC, 8, unsigned int)

/* btmode: 1 == USB, 0 == BCSP */
int go_reset_bt(int btmode)
{
  int fd;
  const char *hwstatus = "/dev/hwstatus";
  /* reboot CSR chip in USB mode */
  fd = open(hwstatus, O_RDWR | O_NOCTTY);
  if (fd == -1) 
  {
    fprintf(stderr, "can't open %s\n", hwstatus);
    exit(-1);
  } 
  else 
  {
    if (ioctl(fd, IOR_BT_MODE, &btmode) == -1)
    {
      fprintf(stderr,"can't ioctl %s\n", hwstatus);
    }
    close(fd);
    DBG("BT held in %s mode\n", btmode ? "usb" : "bcsp");
    usleep(1000000);
    DBG("checking...\n");
  }
  return 0;
}

static void usage(void)
{
#ifndef SUPPORT_USB
    fprintf(stderr, "Usage : csrinit bcsp|h4 devname speed extclkspeed [ep] [nf] [sp] [ns] [cb] [-b <bdaddr>] [-a <ana_trim>] [-c <command>] [-i] [-d]\n");
#else
    fprintf(stderr, "Usage : csrinit bcsp|h4|usb devname speed extclkspeed [ep] [nf] [sp] [ns] [cb] [-b <bdaddr>] [-a <ana_trim>] [-c <command>] [-i] [-d]\n");
    fprintf(stderr, "bcsp and h4 imply serial devname\n");
#endif
    fprintf(stderr, "Commands:\n"
        "\twarm_halt\n"
        "\twarm_reset\n"
        "\tdisable_tx\n"
        "\tenable_tx\n");
}

/******************************************************************************
                         main function
******************************************************************************/
int main(int argc, char *argv[])
{
  int ret = 1; /* error */
  char *cvalue = NULL;
  int opt,index = 0;

  fprintf(stderr, "Csrinit version %d.%d\n", version, revision);
  fprintf(stderr, "Build info: %s %s\n", __DATE__, __TIME__);

  // sanity check number of arguments
  if (argc < 5) 
  {
    fprintf(stderr,"argc < 5 \n");
    usage();
    exit(1);
  }
  // mode
  if (streq(argv[1], "bcsp"))
  {
    // normal serial mode
    mode = BCCMDMODE_UBCSP;
  } 
  else if (streq(argv[1], "h4"))
  {
    mode = BCCMDMODE_H4;
  } 
#ifdef SUPPORT_USB
  else if (streq(argv[1], "usb"))
  {
    mode = BCCMDMODE_USB;
  } 
#endif
  else
  {
      fprintf(stderr,"Mode not correct argv[1]=%s\n",argv[1]);    
      usage();
      exit(1);
  }
  // devname
  char *devName = argv[2];

  // speed
  baudrate = atoi(argv[3]); 
  speed_t speed;

  switch (baudrate)
  {
    case 50:      speed = B50;      break;
    case 75:      speed = B75;      break;
    case 110:     speed = B110;     break;
    case 134:     speed = B134;     break;
    case 150:     speed = B150;     break;
    case 200:     speed = B200;     break;
    case 300:     speed = B300;     break;
    case 600:     speed = B600;     break;
    case 1200:    speed = B1200;    break;
    case 1800:    speed = B1800;    break;
    case 2400:    speed = B2400;    break;
    case 4800:    speed = B4800;    break;
    case 9600:    speed = B9600;    break;
    case 19200:   speed = B19200;   break;
    case 38400:   speed = B38400;   break;
    case 57600:   speed = B57600;   break;
    case 115200:  speed = B115200;  break;
    case 230400:  speed = B230400;  break;
    case 460800:  speed = B460800;  break;
    case 500000:  speed = B500000;  break;
    case 576000:  speed = B576000;  break;
    case 921600:  speed = B921600;  break;
    case 1000000: speed = B1000000; break;
    case 1152000: speed = B1152000; break;
    case 1500000: speed = B1500000; break;
    case 2000000: speed = B2000000; break;
    case 2500000: speed = B2500000; break;
    case 3000000: speed = B3000000; break;
    case 3500000: speed = B3500000; break;
    case 4000000: speed = B4000000; break;
    default: 
      fprintf(stderr,"Invalid speed %s\n", argv[3]);
      usage();
      exit(1);
  }
  
  // extclkspeed
  int extclkspeed = atoi(argv[4]);
  switch (extclkspeed)
  {
        case 16000000:
        case 26000000:
            /* good */
            crystal_freq = extclkspeed;
            DBG("extclkspeed %d\n",extclkspeed);
            if (crystal_freq != 16000000) {
                ext_clock = 1;
            }
            break;
        default:
            fprintf(stderr, "invalid extclkspeed %d\n",extclkspeed);
            usage();
            exit(1);
    }

  
  // get options
  int nrArguments = argc;
  while (--nrArguments >= 5)   // parse remaining options
  {
    if (streq(argv[nrArguments], "ep"))
    {
           DBG("EP specified\n");
      use_enhanced_power_table = 1; // true
    }
    else if (streq(argv[nrArguments], "nf"))
    {
           DBG("NF specified\n");
      use_frequency_trim_value = 0; // false
    }
    else if (streq(argv[nrArguments], "sp"))
    {
           DBG("SP specified\n");
      skip_pskey_protection = 1; // true
    }
    else if (streq(argv[nrArguments], "ns"))
    {
           DBG("NS specified\n");
      no_deep_sleep_during_audio_handling = 1; // true
    }
    else if (streq(argv[nrArguments], "cb"))
    {
           DBG("CB specified\n");
      calc_real_baudrate = 1; // true
    }
  }    
  unsigned char buffer[6];
  char buf[128];
  int n;
  // parse options with - Note : getopt modifies argv[]
  while ((opt=getopt(argc,argv,"a:b:c:id")) != EOF) 
  {
    switch(opt) 
    {
        case 'a':
          // ana trim
      DBG("optarg ana trim: %s (hexadecimal)\n", optarg);
          ana_trim = (int) strtol(optarg,0,16);
      if ((errno == EINVAL) && (ana_trim == 0))
      { 
          fprintf(stderr,"Warning: strange ana trim value: %s\n",optarg);
          usage();
          exit(1);
      }
          break;
        case 'b':
          // bd addr
          btAddrSpecifiedOnCommandLine = 1;

          DBG("start scanning bluetooth address\n");      
          int len = strlen(optarg);

      DBG("strlen optarg: %d\n", len);

      if ((len == 12) || (len==17))
      {
          int i = 0;
          int index = 0;
          char tmp[3];
          tmp[2]='\0';
          long int value;
          while (i<len)
        {
            if (optarg[i]==':') i++;
            tmp[0] = optarg[i];
            tmp[1] = optarg[i+1];
            i=i+2;
//                DBG("Result: %02x\n", strtol(tmp,0,16));
            value = strtol(tmp,0,16);
            if ((errno == EINVAL) && (value == 0))
            {
              DBG("Warning: strange MAC address: %s\n",optarg);
              memset(bdAddress, ~0, sizeof(bdAddress));
              break;
            }
            else
            {
            bdAddress[index++]= (uint8) value;
            }
        }    
          DBG("BDADDR=%02X:%02X:%02X:%02X:%02X:%02X\n",bdAddress[0], bdAddress[1], bdAddress[2], bdAddress[3], bdAddress[4], bdAddress[5]);
      }
      else 
      {
        DBG("Warning: strange MAC address: %s\n",optarg);
        usage();
        exit(1);
      }
          break;
        case 'c':
          // command
          cvalue = optarg;
          DBG("Got command=%s\n",cvalue);
      if (streq(cvalue, "warm_halt"))
          {
              warm_halt = 1; 
          }
          else if (streq(cvalue, "warm_reset"))
          {
              warm_reset = 1; 
          }
          else if (streq(cvalue, "disable_tx"))
          {
              disable_tx = 1; 
          }
          else if (streq(cvalue, "enable_tx"))
          {
              enable_tx = 1; 
          }
      else 
      {
        fprintf(stderr, "Command not supported\n");    
        usage();
        exit(1);
      }
          break;
        case 'i':
          ignore_unknown_bd_address = 1;
          break;
        case 'd':
          debug = 1;
          break;
        default:
             fprintf(stderr, "- option not supported\n");    
          usage();
          exit(1);
    }
  }

      if (mode != BCCMDMODE_USB)
      {
        go_reset_bt(0);
        DBG("going for baudrate %d\n", baudrate);

        /* open serial port */
        if ((serialfd = serial_open(devName, speed)) < 0)
          return 1;
        ps_uart_baudrate_value = calc_ps_uart_baudrate_value(real_baudrate);
        DBG("requested baudrate %d | real baudrate =%d | ps_uart_baudrate_value =%d\n", baudrate,real_baudrate ,ps_uart_baudrate_value);
      }
#ifdef SUPPORT_USB
      else
      {
        /* HCI over USB mode */
        go_reset_bt(1);
      }
#endif

    /* initialize BCSP stack */
    /* some state might also be needed for USB */
    ubcsp_initialize();

    /* configure the CSR BlueCore */
    if (mode != BCCMDMODE_USB)
    {
      int x;
      /* do h4 of ubcsp over serial */
      x = do_pretty_amazing_magic();
      while (x < 0)
      {
        printf("RETRYING WITH RESET\n");
        go_reset_bt(0);
        DBG("going for baudrate %d\n", baudrate);

        /* open serial port */
        if ((serialfd = serial_open(devName, speed)) < 0)
          return 1;
        ps_uart_baudrate_value = calc_ps_uart_baudrate_value(real_baudrate);
        DBG("requested baudrate %d | real baudrate =%d | ps_uart_baudrate_value =%d\n", baudrate,real_baudrate ,ps_uart_baudrate_value);
         ubcsp_initialize();
        x = do_pretty_amazing_magic();
      }  
      usleep(1000000);
      /* now, wait until bluez picks up USB device */
      return 0;
    }
    else
    {
      /* use libusb to turn the BCXROM into a real BT-HCI device */
#ifdef SUPPORT_USB
      ret = open_usb_conn(); /* argv[2] ingored */
      switch (ret)
      {
        case 0:
          do_pretty_amazing_usb_magic();
          ret = 0;
          /* succesfull ? wait until device is alive */
          usleep(1000000);
          /* fallthrough */
        case 1:
        default:
          close_usb_conn();
          return ret;
      }
#else
      return -1;
#endif
    }
}
