// 
// This header file contains the patches for CSR BC4-ROM build id 3164.
// Author: Jeroen Egelmeers
// 
// 
// Following information about the patches from CSR:
// =============================================================================
// 
// Created by patchmaker.pl $Revision: #19 $ $Date: 2007/07/09 $
// Creation date: Tue Jul 10 11:10:15 2007
// 
// Patch is for build 3164 odj_4hci_rom_bt2.0_21e_0604241634_encr128
// Input file: build_3164_patches.xap.
// Depot file: //depot/bc/unified-21e/dev/patches/3164/build_3164_patches.xap
// File revision: 4
// 
// this fixes B-22675,B-19666,B-19739,B-21790,B-23436,B-24330,B-26596,B-27804
// 
// B-22675
// The firmware could panic if it received data from the host for a remote 
// device that had reconnected before that same device's previous connection 
// had timed out. This would typically occur if the remote device reset whilst 
// streaming data and immediately tried to reconnect. 
// 
// B-19666
// An issue has been identified whereby one of the BlueCore-F�s occasional -A
// internal trims can, under limited circumstances, cause the chip to transmit 
// a single corrupted ACL-U data packet.
// 
// B-21790
// When PSKEY_UART_HOST_WAKE and PSKEY_UART_HOST_WAKE_SIGNAL were configured, 
// it was possible that the wake-up PIO pins and the Clock Request line could 
// be pulsed even if there was no data to transmit. 
// 
// B-23436
// When BlueCore was a slave of a link, it was possible that it would not begin
// AFH channel classification until the master had classified its channels, by 
// sending an LMP_set_afh. If the master device did not detect any interferrers,
// this could means that the slave never performed channel classification. 
// 
// B-24330
// This patch fixes a bug with edr and agc
// 
// B-26596
// This patch improves RX performance on some parts by
// using slightly different initialisation.
// 
// B-27804
// When a device is a master and a slave and its slave link has an eSCO with
// retransmits, the master link can time out.



//////////////////////////////////////////////////////////////////////////////
// patch_hardware_6, PSKEY_PATCH56 (0x2132, 8498)
uint16 csr_b3164_patch_56_pskey = 0x2132;
uint16 csr_b3164_patch_56_data[] = {
       0x0001, 0xf61f, 0xf900, 0xb599, 0x37f0, 0xfe0a, 0xff3c, 0x0114, 
       0xf900, 0xb525, 0x0110, 0xf800, 0x4614, 0x0618, 0x0638, 0x0638, 
       0xfd00, 0x7a38, 0x0126, 0x0022, 0x025c, 0xe12d, 0xe115, 0x0018, 
       0xff2b, 0xff0e, 0xf800, 0xdf18, 0x009e, 0x0010, 0xf900, 0xb521, 
       0xf000, 0xff21, 0xff27, 0x0110, 0xf600, 0x1f14, 0x0618, 0x0638, 
       0x0638, 0xfd00, 0x7a38, 0x0126, 0x0022, 0xff17, 0x0084, 0x09f4, 
       0x043c, 0xfe0e, 0x0018, 0xfe2b, 0xfe0e, 0x5b00, 0x9c18, 0x00e2, 
       0x043c, 0xfe0e, 0xffe3, 0x0018, 0xf12b, 0xf10e, 0xf800, 0x4c18, 
       0x00e2, 0xb75a };

//////////////////////////////////////////////////////////////////////////////
// patch_lc_update_atten, PSKEY_PATCH28 (0x00b2, 178)
uint16 csr_b3164_patch_28_pskey = 0x00b2;
uint16 csr_b3164_patch_28_data[] = {
       0x0313, 0x0280, 0x10f0, 0xf200, 0x8515, 0x0184, 0x06f0, 0x051b, 
       0x6016, 0x0777, 0x0a84, 0x0dfc, 0x0018, 0xfe2b, 0xc200, 0x1918, 
       0xff2b, 0x08e0, 0x0018, 0xfe2b, 0xc200, 0xff18, 0xff2b, 0x02e0, 
       0x0c3c, 0xfe0e, 0xffe3, 0x444b };

//////////////////////////////////////////////////////////////////////////////
// patch_hardware_7, PSKEY_PATCH57 (0x2133, 8499)
uint16 csr_b3164_patch_57_pskey = 0x2133;
uint16 csr_b3164_patch_57_data[] = {
       0x0002, 0x3b61, 0x0114, 0x0118, 0xff2b, 0xff0e, 0xe000, 0x2218, 
       0x009e, 0x093c, 0xfe0e, 0xffe3, 0xc6ea };

//////////////////////////////////////////////////////////////////////////////
// patch_lc_init_radio, PSKEY_PATCH22 (0x00ac, 172)
uint16 csr_b3164_patch_22_pskey = 0x00ac;
uint16 csr_b3164_patch_22_data[] = {
       0x1a00, 0x1714, 0x0100, 0xe825, 0x0214, 0x0100, 0xe725, 0x00e2, 
       0x071e };

//////////////////////////////////////////////////////////////////////////////
// patch_hardware_3, PSKEY_PATCH53 (0x212f, 8495)
uint16 csr_b3164_patch_53_pskey = 0x212f;
uint16 csr_b3164_patch_53_data[] = {
       0x0002, 0x9742, 0x0617, 0x0ef0, 0x0117, 0x0118, 0xff2b, 0xff0e, 
       0x9200, 0x0918, 0x009e, 0x0327, 0x0bf0, 0x0014, 0x083c, 0xfe0e, 
       0xffe3, 0x0118, 0xff2b, 0xff0e, 0x9700, 0x4618, 0x00e2, 0x0118, 
       0xff2b, 0xff0e, 0x9700, 0x4f18, 0x00e2, 0xeb3a };

//////////////////////////////////////////////////////////////////////////////
// patch_hardware_4, PSKEY_PATCH54 (0x2130, 8496)
uint16 csr_b3164_patch_54_pskey = 0x2130;
uint16 csr_b3164_patch_54_data[] = {
       0x0003, 0x6df1, 0xfe27, 0xfd27, 0x0218, 0xff2b, 0xff0e, 0x6e00, 
       0xf418, 0x00e2, 0x4005 };

//////////////////////////////////////////////////////////////////////////////
// patch_hardware_2, PSKEY_PATCH52 (0x212e, 8494)
uint16 csr_b3164_patch_52_pskey = 0x212e;
uint16 csr_b3164_patch_52_data[] = {
       0x0001, 0x9e3c, 0x0117, 0x0118, 0xff2b, 0xff0e, 0x9700, 0x3a18, 
       0x009e, 0x0084, 0x0af0, 0x071b, 0x0016, 0x0fa4, 0x0018, 0xff2b, 
       0xff0e, 0x9e00, 0x3f18, 0x00e2, 0x0114, 0x103c, 0xfe0e, 0xffe3, 
       0x8e60 };

//////////////////////////////////////////////////////////////////////////////
// patch_hardware_5, PSKEY_PATCH55 (0x2131, 8497)
uint16 csr_b3164_patch_55_pskey = 0x2131;
uint16 csr_b3164_patch_55_data[] = {
       0x0001, 0x1e5c, 0x0010, 0x0521, 0xf000, 0x3d19, 0x3012, 0xf000, 
       0x3c19, 0x3116, 0x03f4, 0x3216, 0x02f0, 0x3022, 0xf000, 0x3c15, 
       0xf000, 0x3d11, 0x0018, 0xff2b, 0xff0e, 0x1e00, 0x6018, 0x00e2, 
       0xef1e };
