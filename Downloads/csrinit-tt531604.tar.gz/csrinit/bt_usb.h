int open_usb_conn();
int send_usb_packet(unsigned char *data, int len);
int	usb_receive_packet(struct ubcsp_packet *receive_packet);
void close_usb_conn();
